if text.endswith(""):
    text = text[:-0]
