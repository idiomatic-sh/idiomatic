''.strip('aa')  # noqa: F401
