value = outer(deep(leaf(a)), shallow(b))
unrelated = [[[[[[[[[[[[[[[[0]]]]]]]]]]]]]]]]
