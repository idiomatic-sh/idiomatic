'{0:{width:d}}'.format(1,width=3)
