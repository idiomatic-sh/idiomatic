obj.d={}
if key in obj.d: del obj.d[key]
