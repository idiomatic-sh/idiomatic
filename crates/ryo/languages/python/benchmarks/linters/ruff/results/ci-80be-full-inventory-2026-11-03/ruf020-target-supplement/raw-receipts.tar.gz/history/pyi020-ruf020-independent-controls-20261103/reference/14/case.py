from __future__ import annotations
from functools import singledispatch
from typing import Never
@singledispatch
def fun(x): ...
fun=custom
@fun.register
def f[Never](x:Never | int)->Never | int: ...
