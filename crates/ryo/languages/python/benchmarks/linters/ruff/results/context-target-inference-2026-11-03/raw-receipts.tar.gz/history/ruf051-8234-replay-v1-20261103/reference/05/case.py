d={}
if key in d: del d[other]
