from pathlib import Path
import re,ast,hashlib,json,sys,tomllib,tokenize,io,shutil
work=Path('/tmp/ple0115-ple0117-validity-certificates-20261103');root=work/'crates/ryo/languages/python/benchmarks/linters/ruff';sys.path.insert(0,str(root))
from authoring import profile_config as c,profile_sources as s,profile_proofs as p,rule_registration as reg,reference_discrepancies as d
raw=Path('/tmp/ple0115-ple0117-ci-regression-audit-20261103');failed=json.loads((raw/'failed-inputs.json').read_text())
base=tomllib.loads((root/'benchmark.toml').read_text());phases=json.loads(c.RULE_PHASES_FILE.read_text());manifest=json.loads(c.MANIFEST.read_text());native=p.native_descriptor_json(c.NATIVE_DESCRIPTOR_FILE.read_text())
pre=raw/'original-stage-v2'
profiles={code:reg.stage_full_inventory_rule(code,pre,base,phases,manifest,native)[0] for code in ['PLE0115','PLE0117']}

def independent_spans(source):
    tree=ast.parse(source);bad=[]
    def scope(body):
        declarations=[]
        def scan(node):
            if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
                scope(node.body);return
            if isinstance(node,(ast.Global,ast.Nonlocal)):declarations.append(node)
            for child in ast.iter_child_nodes(node):scan(child)
        for node in body:scan(node)
        globals={name for node in declarations if isinstance(node,ast.Global) for name in node.names}
        for node in declarations:
            if isinstance(node,ast.Nonlocal):
                for token in tokenize.generate_tokens(io.StringIO(source).readline):
                    if token.type==tokenize.NAME and node.lineno <= token.start[0] <= node.end_lineno and token.string in node.names and token.string in globals:
                        lines=source.splitlines(keepends=True)
                        start=sum(len(x.encode()) for x in lines[:token.start[0]-1])+len(lines[token.start[0]-1][:token.start[1]].encode())
                        end=start+len(token.string.encode());bad.append((start,end))
    scope(tree.body);return sorted(bad)
policy=[]
for item in failed:
    extra=[]
    for filename,source in item['files'].items():extra += [dict(rule='invalid-syntax',file=filename,start=a,end=b) for a,b in independent_spans(source)]
    intended=item['reference']+extra
    assert d.discrepancy_output(list(item['files']),intended)==d.discrepancy_output(list(item['files']),item['candidate'])
    item['intended']=intended;policy.append(dict(rule=item['rule'],case=item['name'],source_sha256=hashlib.sha256(next(iter(item['files'].values())).encode()).hexdigest(),independently_derived_validation_spans=extra,original_lint_multiset=item['reference']))
(raw/'independent-spans-and-policy.json').write_text(json.dumps(dict(policy='Each nonlocal name conflicting with a global declaration in the same lexical scope receives one validation diagnostic at its original name token. AST syntax acceptance remains Accepted, diagnostic phase Validation and tree impact Preserved. CPython proves compiler invalidity, not this multi-error reporting policy. Compiler diagnostics survive lint noqa suppression.',cases=policy),indent=2)+'\n')
for code in ['PLE0115','PLE0117']:
    path=root/f'rules/{code}/cases.toml';text=path.read_text();cases=tomllib.loads(text)['cases'];evidence=root/f'profiles/{code}/evidence';evidence.mkdir(exist_ok=True)
    names=['compile-controls.py','compile-controls-inputs.json','compile-controls-results.json','compile-controls-invocation.json','independent-spans-and-policy.json']
    for name in names:shutil.copyfile(raw/name,evidence/name)
    annotations={};intended_by_name={}
    for item in failed:
        if item['rule']!=code:continue
        case=next(x for x in cases if x['name']==item['name']);assert case['expected']==item['reference']
        case['expected']=item['intended'];case['comparison']='full';intended_by_name[item['name']]=case['expected']
        source=hashlib.sha256()
        for name,value in sorted(case['files'].items()):source.update(name.encode());source.update(b'\0');source.update(value.encode())
        invocation=dict(arguments=['check','--isolated','--output-format','json','--cache-dir','$STATE/ruff','--select',code,'--target-version','py310','--','case.py'],environment={'RAYON_NUM_THREADS':'1'},directory='$ROOT',parser_configuration='python-target=3.10',project_context_mode='Isolated')
        annotation=dict(expected=item['reference'],identity={'tool':'ruff','version':'0.16.5','observed-executable-sha256':'52469aac0ad5cd499c3cd1f72993a9f3eb237fd975f53d6873b4245190e7d0e8','profile-sha256':c.sha256(profiles[code]/'benchmark.toml'),'settings-sha256':d.discrepancy_json_hash(invocation),'source-sha256':source.hexdigest(),'reference-output-sha256':d.discrepancy_json_hash(d.discrepancy_output(list(case['files']),item['reference'])),'intended-output-sha256':d.discrepancy_json_hash(d.discrepancy_output(list(case['files']),case['expected']))},evidence=[dict(path='evidence/'+name,sha256=c.sha256(evidence/name),kind='independent-language-run',**{'language-version':'CPython 3.10.19','target-configuration':'python-target=3.10','version-rationale':'Actual CPython3.10.19 parses each unchanged source but rejects compilation for the same-scope global/nonlocal conflict. Removing nonlocal declarations compiles, and removing global from the real enclosing-binding control compiles. Source, executable, script, input and output hashes are retained. Independent AST/token derivation specifies one validation finding per conflicting nonlocal name; CPython is not claimed to prove multi-error count or these name-token spans.'}) for name in names],reason='Exact reference omission of compiler-validity diagnostics: a name cannot be both global and nonlocal in the same scope. Preserve all original lint findings and their multiplicities. Add one independently token-derived invalid-syntax name span for each conflicting nonlocal declaration, including when lint noqa is present. AST parsing succeeds and complete facts remain available; these are Validation/Preserved diagnostics. Ruff omits these additional compiler errors under this pinned selection. This certificate applies only to this exact source and diagnostic multiset.')
        annotations[item['name']]=annotation
    chunks=text.split('[[cases]]');new=[chunks[0]]
    for case,chunk in zip(cases,chunks[1:],strict=True):
        if case['name'] in annotations:
            chunk=re.sub(r'(?ms)^expected\s*=\s*\[.*?\]', lambda _: 'expected = '+s.toml_value(case['expected']), chunk)
            lines=chunk.splitlines();lines=[('comparison = "full"' if line.startswith('comparison =') else 'expected = '+s.toml_value(case['expected']) if line.startswith('expected =') else line) for line in lines]
            if not any(x.startswith('comparison =') for x in lines):lines.insert(2,'comparison = "full"')
            chunk='\n'.join(lines).rstrip()+'\nreference-discrepancy = '+s.toml_value(annotations[case['name']])+'\n\n'
        new.append('[[cases]]'+chunk)
    path.write_text(''.join(new))
    stage,registration=reg.stage_full_inventory_rule(code,raw/'certified-stage-v2',base,phases,manifest,native)
    (raw/f'{code}-registration.json').write_text(json.dumps(registration,indent=2)+'\n')
    print(code,len(cases),'cases',len(annotations),'certificates',stage)
