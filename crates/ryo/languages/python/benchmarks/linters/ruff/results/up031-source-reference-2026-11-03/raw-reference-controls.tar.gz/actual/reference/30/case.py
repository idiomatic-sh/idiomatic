template % value
