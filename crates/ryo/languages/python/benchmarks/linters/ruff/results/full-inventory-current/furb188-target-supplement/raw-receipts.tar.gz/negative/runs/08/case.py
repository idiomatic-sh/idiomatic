if text.startswith("a\nb"):
    text = text[3:]
