text = ''
text.lstrip('aa')
