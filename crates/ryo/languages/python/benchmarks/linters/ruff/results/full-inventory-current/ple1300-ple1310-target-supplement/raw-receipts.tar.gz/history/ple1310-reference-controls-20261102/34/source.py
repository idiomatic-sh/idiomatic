''.strip((
    'aa'
))
