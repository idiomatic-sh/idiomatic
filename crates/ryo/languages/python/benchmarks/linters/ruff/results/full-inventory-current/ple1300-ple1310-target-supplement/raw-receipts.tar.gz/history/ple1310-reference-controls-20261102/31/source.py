''.strip('aa', extra=1)
