from typing import TYPE_CHECKING, TypeAlias
Alias:TypeAlias=Undefined
