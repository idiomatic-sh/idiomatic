Alias = list["not valid Python"]
