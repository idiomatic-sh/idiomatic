'{:qabc}'.format(1)
