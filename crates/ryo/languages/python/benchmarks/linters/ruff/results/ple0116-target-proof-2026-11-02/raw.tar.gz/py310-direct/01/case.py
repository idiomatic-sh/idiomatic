while True:
    try:
        pass
    finally:
        if ready:
            continue
