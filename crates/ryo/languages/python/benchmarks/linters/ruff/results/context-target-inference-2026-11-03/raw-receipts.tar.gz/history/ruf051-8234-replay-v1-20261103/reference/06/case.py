d={}
other={}
if key in d: del other[key]
