"%.*f" % (3,value)
