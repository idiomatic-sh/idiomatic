'{:.٢f}'.format(1.2)
