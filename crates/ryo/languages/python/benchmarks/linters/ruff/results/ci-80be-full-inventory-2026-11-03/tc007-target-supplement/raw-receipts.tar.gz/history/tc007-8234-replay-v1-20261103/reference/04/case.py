import typing as t
if t.TYPE_CHECKING:
 class Foo: ...
Alias:t.TypeAlias=Foo
