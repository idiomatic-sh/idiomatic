b''.strip(b'\x00')
