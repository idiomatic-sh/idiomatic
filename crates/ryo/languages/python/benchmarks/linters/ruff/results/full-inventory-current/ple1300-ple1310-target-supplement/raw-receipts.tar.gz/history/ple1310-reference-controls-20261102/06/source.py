b''.strip(b'a\x61')
