if (d:={}): pass
if key in d: del d[key]
