class Custom:
    def __format__(self, spec):
        return 'accepted:' + spec
'{:q}'.format(Custom())
