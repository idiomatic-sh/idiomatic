text = ''
text = b''
text.strip(b'aa')
