while True:
    try:
        pass
    finally:
        continue  # noqa: PLE0116
