class C:
    __slots__ = [b"z", b"a"]
