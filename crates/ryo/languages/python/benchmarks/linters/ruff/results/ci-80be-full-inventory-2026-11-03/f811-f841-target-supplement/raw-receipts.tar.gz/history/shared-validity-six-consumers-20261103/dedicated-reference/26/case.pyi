def outer():
 class C((value:=object)):
  def f(self):
   global value
   nonlocal value
