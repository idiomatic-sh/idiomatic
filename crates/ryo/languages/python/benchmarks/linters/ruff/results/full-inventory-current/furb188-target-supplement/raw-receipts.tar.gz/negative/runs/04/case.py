result = text[:-4] if text.endswith(".txt") else text
