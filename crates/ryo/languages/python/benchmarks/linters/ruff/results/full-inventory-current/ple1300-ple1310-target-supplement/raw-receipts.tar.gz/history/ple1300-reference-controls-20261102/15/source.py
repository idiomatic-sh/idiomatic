'{:}'.format(1)
