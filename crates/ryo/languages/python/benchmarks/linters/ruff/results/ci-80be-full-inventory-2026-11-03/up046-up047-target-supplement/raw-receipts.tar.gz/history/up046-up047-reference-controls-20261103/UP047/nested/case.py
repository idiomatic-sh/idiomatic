from typing import Generic, TypeVar, AnyStr
T = TypeVar("T")
def outer():
 def f(x:T): ...
