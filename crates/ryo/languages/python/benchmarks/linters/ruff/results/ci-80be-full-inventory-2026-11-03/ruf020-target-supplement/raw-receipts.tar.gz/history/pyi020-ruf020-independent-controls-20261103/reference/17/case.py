from __future__ import annotations
Never=custom
def outer():
 from typing import Never
 def f()->Never | int: ...
