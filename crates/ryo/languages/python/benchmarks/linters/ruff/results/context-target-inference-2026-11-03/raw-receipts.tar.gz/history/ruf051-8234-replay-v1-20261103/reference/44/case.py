del d
d={}
if key in d: del d[key]
