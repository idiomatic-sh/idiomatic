async def sample():
    value = outer(deep(leaf(await a())), shallow(b))
