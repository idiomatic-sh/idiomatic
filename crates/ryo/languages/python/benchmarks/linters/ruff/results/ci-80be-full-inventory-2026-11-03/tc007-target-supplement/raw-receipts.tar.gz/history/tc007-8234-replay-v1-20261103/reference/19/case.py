from typing import TYPE_CHECKING, TypeAlias
Foo:int
Alias:TypeAlias=Foo
