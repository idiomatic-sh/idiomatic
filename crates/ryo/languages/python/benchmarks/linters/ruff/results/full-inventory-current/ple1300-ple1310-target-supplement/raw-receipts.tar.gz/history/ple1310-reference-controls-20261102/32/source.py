''.strip(*['aa'])
