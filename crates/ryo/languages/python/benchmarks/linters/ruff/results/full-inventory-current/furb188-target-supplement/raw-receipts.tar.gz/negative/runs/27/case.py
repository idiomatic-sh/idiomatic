if text.startswith("a"):
    text = other = text[1:]
