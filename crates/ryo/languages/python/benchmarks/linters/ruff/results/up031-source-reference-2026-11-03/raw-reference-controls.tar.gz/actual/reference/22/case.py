"%d" % [value]
