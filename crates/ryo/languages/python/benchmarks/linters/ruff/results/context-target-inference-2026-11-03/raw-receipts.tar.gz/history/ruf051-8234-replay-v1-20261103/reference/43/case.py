from __future__ import annotations
def f[dict](d:dict):
 if key in d: del d[key]
