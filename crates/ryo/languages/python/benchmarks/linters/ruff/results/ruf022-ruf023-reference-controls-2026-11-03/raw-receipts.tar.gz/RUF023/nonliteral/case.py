class C:
    __slots__ = ["z", dynamic, "a"]
