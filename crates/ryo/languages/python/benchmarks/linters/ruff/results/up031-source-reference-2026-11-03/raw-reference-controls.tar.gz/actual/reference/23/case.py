"%q" % value
