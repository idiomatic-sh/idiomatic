import collections,json,pathlib,time
root=pathlib.Path('/tmp/django-required-live-bounded-trace-20261102')
start=time.perf_counter();events=collections.Counter();targets=collections.Counter();nodes=collections.Counter();files=collections.Counter();rules=collections.Counter();file_cells=collections.Counter();node_cells=collections.Counter();starts=collections.Counter();ends=collections.Counter();samples={};current_file=None;current_rule=None;last_rule_start=None;total=0
for line in (root/'events.jsonl').open():
    x=json.loads(line);f=x.get('fields',{});event=f.get('event');target=x.get('target');events[event]+=1;targets[target]+=1;total+=1
    if event=='rule_file_start':
        current_file=f.get('file');current_rule=f.get('rule');starts[(current_file,current_rule)]+=1;last_rule_start={'file':current_file,'rule':current_rule,'timestamp':x.get('timestamp')}
    elif event=='rule_file_end':
        ends[(f.get('file'),f.get('rule'))]+=1;current_file=None;current_rule=None
    elif event=='dag_node':
        node=f.get('node');cells=f.get('cells',0);nodes[node]+=1;node_cells[node]+=cells;files[current_file]+=1;file_cells[current_file]+=cells;rules[current_rule]+=1
        if node not in samples:samples[node]={'file':current_file,'rule':current_rule,'first_fields':f}
unmatched=[{'file':file,'rule':rule,'starts':count,'ends':ends[(file,rule)]} for (file,rule),count in starts.items() if count!=ends[(file,rule)]]
summary={'schema':'bounded-file-dag-trace/v1','lines':total,'parse_seconds':time.perf_counter()-start,'events':events.most_common(15),'targets':targets.most_common(15),'dag_node_events':sum(nodes.values()),'unique_nodes':len(nodes),'top_nodes':[{'node':n,'events':count,'cells_sum':node_cells[n],**samples[n]} for n,count in nodes.most_common(15)],'top_files':[{'file':file,'dag_node_events':count,'cells_sum':file_cells[file]} for file,count in files.most_common(15)],'top_rules':rules.most_common(15),'last_rule_start':last_rule_start,'unmatched_rule_file_pairs':unmatched[:30],'unmatched_pair_count':len(unmatched)}
(root/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps({'lines':total,'dag_node_events':summary['dag_node_events'],'top_nodes':[(x['node'],x['events'],x['file'],x['rule']) for x in summary['top_nodes'][:5]],'top_files':[(x['file'],x['dag_node_events']) for x in summary['top_files'][:5]],'unmatched':unmatched[:3],'parse_seconds':summary['parse_seconds']}))
