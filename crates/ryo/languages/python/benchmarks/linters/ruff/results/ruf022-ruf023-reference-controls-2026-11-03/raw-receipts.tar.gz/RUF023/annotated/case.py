class C:
    __slots__: list[str] = ["z", "a"]
