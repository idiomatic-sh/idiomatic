from typing import Literal
x: "Literal[Literal[1]]"
