if text.startswith("a"):
    text: str = text[1:]
