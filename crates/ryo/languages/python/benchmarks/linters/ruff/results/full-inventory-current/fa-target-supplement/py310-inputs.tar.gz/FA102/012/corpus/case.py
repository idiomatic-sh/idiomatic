from __future__ import annotations
x: int | str
