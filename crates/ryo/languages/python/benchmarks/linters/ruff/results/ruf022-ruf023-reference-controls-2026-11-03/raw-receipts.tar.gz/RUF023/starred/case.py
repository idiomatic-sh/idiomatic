class C:
    __slots__ = ["z", *items, "a"]
