d=dict[int,str]()
if key in d: del d[key]
