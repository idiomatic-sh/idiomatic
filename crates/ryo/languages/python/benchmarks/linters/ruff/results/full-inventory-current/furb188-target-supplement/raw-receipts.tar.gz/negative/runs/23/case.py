if text.endswith("a"):
    text = text[:1]
