# ruff: noqa: FURB188
if text.startswith("a"):
    text = text[1:]
