class C:
    __slots__ = {"z", "a"}
