from typing import Literal
x=Literal[1][Literal[Literal[2]]]
