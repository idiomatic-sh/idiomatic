def f(x:(value:=object)):
 global value
 nonlocal value
from __future__ import annotations
