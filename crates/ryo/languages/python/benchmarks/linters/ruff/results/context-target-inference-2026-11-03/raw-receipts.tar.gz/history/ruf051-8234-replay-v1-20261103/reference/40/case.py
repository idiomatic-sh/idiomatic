from __future__ import annotations
def f(d:dict):
 dict=custom
 if key in d: del d[key]
