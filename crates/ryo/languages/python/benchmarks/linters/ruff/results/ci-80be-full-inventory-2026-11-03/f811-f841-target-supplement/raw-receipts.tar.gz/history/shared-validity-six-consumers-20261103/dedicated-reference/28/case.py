def outer[T]():
 def f():
  global T
  nonlocal T
