from typing import Optional
def f():
    x: Optional["X"]
