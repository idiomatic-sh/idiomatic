d={}
if (1,2) in d: del d[1,2]
