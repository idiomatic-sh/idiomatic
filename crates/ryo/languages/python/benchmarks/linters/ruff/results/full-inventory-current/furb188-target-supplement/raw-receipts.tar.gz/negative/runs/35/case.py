result = text[1:] if text.startswith("a") else text  # noqa: FURB188
