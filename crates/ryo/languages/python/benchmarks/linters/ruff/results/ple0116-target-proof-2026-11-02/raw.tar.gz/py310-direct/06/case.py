while True:
    try:
        pass
    finally:
        while ready:
            continue
