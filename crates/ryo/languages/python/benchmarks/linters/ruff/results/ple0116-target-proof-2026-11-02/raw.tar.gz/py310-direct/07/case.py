while True:
    try:
        pass
    finally:
        while ready:
            break
        else:
            continue
