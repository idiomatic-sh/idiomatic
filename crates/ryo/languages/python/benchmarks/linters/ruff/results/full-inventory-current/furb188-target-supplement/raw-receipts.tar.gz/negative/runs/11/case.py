from builtins import len as size
if text.endswith(suffix):
    text = text[:-size(suffix)]
