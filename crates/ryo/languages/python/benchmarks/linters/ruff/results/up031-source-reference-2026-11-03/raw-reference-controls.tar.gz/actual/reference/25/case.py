"%d" "%q" % value
