from typing import Callable
x: Callable[[int], str]
