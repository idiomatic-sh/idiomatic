while True:
    try:
        pass
    finally:
        try:
            continue
        except Exception:
            pass
