from typing import Optional
x: Optional[int]
