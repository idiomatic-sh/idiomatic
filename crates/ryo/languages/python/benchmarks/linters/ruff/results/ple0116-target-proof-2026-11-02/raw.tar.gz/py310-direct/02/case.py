while True:
    try:
        pass
    finally:
        if ready:
            pass
        else:
            continue
