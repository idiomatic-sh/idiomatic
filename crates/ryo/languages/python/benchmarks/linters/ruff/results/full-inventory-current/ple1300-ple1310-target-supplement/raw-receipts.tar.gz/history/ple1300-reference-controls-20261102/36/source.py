'{:q}'.format(1)  # noqa: PLE1300
