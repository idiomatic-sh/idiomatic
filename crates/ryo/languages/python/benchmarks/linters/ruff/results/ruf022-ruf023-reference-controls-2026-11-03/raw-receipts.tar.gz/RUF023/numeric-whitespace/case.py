class C:
    __slots__ = ["12", "1 2"]
