"%()s" % {"":value}
