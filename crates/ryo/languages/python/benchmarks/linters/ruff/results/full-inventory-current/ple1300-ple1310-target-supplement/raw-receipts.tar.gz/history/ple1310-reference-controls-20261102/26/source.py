f''.strip('aa')
