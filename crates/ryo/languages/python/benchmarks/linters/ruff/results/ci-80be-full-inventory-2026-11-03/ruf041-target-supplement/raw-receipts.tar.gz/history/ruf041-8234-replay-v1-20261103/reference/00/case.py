from typing import Literal
x=Literal[Literal[1],2]
