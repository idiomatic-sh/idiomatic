#!/usr/bin/env bash
set -uo pipefail
worker=/tmp/required-live-worker-release-20261102/python-release-sealed
ruff=/home/vscode/.local/bin/ruff
base=/tmp/required-live-target-replays-20261102
for rule in RUF101 N999; do
  output="$base/$rule"
  mkdir -p "$output"
  RYO_VERIFY_CASE_RESULTS="$output/cases.jsonl" "$worker" verify-cases "$ruff" "$base/profiles/$rule/repro" > "$output/stdout.bin" 2> "$output/stderr.bin"
  code=$?
  printf '%s\n' "$code" > "$output/exit-code"
  printf '%s %s\n' "$rule" "$code"
done
