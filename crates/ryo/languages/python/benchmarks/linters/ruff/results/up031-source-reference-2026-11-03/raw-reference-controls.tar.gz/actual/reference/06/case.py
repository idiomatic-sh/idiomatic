"%r" % value
