class C:
    def f(self):
        __slots__ = ["z", "a"]
