d={}
if 0x10 in d: del d[16]
