from __future__ import annotations
def f(d:dict,dict):
 if key in d: del d[key]
