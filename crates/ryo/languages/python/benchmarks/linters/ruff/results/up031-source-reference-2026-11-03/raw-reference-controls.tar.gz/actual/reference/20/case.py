"%(x)s" % {**mapping}
