class C:
    __slots__ = {"z": "doc", "a": "doc"}
