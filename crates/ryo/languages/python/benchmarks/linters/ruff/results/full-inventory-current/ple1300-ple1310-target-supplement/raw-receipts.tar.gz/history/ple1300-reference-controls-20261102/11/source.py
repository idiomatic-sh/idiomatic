'{:q}'.format(1)
