while True:
    try:
        pass
    finally:
        with resource:
            continue
