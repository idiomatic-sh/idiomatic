if text.startswith("a", 0):
    text = text[1:]
