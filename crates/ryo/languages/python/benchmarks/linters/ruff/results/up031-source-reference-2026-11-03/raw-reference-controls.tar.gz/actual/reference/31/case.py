format = object()
"%s" % value
