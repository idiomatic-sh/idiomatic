text.strip('aa')
