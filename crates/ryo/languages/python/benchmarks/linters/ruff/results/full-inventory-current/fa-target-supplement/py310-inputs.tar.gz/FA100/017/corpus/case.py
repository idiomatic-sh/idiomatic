from typing import List
def f():
    x: List[int]
