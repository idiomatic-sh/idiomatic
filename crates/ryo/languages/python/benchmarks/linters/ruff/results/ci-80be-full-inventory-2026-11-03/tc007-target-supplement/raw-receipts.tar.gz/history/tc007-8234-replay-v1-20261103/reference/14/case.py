from typing import TYPE_CHECKING, TypeAlias
class Foo: ...
if TYPE_CHECKING:
 from external import Foo
Alias:TypeAlias=Foo
