import json
s='from typing import TYPE_CHECKING\nif TYPE_CHECKING:\n from external import Foo\nx=Foo\n'
try:
 exec(compile(s,"value-use.py","exec",dont_inherit=True),{})
except NameError as e:
 print(json.dumps({"source":s,"expected":"NameError","actual":type(e).__name__,"passed":True}))
else:
 raise AssertionError("missing guard-only failure")
