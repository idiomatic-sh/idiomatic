'{:q}{:y}'.format(1,2)
