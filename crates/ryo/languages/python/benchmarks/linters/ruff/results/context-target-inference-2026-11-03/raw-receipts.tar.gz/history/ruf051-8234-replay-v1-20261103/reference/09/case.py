d={}
if key in d: del d[key]
else: pass
