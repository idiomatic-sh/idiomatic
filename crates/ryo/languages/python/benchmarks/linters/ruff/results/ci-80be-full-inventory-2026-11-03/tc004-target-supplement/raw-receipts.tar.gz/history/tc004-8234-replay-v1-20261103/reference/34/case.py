from typing import TYPE_CHECKING
if TYPE_CHECKING:
 from external import Foo
def __getattr__(name): return 1
__all__=["Foo"]
