'hello'.strip('aba')
