from typing import Literal
class C[Literal]:
 x:Literal[Literal[1]]
