class C:
    __slots__ = ["item2", "item10"]
