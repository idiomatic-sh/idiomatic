10 % value
