b'%q' % b'x'
