b''.rstrip(b'\xffa\xff')
