from typing import TYPE_CHECKING
if TYPE_CHECKING:
 from external import Foo
def f():
 Foo=1
 return Foo
