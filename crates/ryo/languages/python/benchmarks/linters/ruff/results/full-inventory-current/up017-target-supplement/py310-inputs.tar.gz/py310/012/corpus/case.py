# ruff: noqa: UP017
import datetime
datetime.timezone.utc
