"%d" % value
