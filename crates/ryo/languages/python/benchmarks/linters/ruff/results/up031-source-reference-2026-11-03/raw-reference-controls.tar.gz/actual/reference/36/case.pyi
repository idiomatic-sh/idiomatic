x: str
"%s" % value
