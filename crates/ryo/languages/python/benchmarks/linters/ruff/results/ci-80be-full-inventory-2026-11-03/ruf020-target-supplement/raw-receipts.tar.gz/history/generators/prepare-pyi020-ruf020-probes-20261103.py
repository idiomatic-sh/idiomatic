from pathlib import Path
import json
out=Path('/tmp/pyi020-ruf020-independent-controls-20261103');out.mkdir(exist_ok=True)
base='from __future__ import annotations\nfrom typing import Never,Union\n'
probes=[
 {'name':'future-generic-never','source':base+'def f[Never]()->Never | int: ...\n','parameter':True},
 {'name':'native-generic-never','source':'from typing import Never\ndef f[Never]()->Never | int: ...\n','parameter':True},
 {'name':'quoted-generic-never','source':'from typing import Never\ndef f[Never]()->"Never | int": ...\n','parameter':True},
 {'name':'generic-union-shadow','source':base+'def f[Union]()->Union[Never,int]: ...\n','error':'TypeError'},
 {'name':'generic-module-shadow','source':'from __future__ import annotations\nimport typing as t\ndef f[t]()->t.Never | int: ...\n','error':'AttributeError'},
 {'name':'future-generic-independent-positive','source':base+'def f[T]()->Never | int: ...\n','bottom':True},
 {'name':'native-generic-independent-positive','source':'from typing import Never\ndef f[T]()->Never | int: ...\n','bottom':True},
 {'name':'module-vs-enclosing-local','source':'from __future__ import annotations\nNever=str\ndef outer():\n from typing import Never\n def f()->Never | int: ...\n return f\nf=outer()\n','resolution_pair':True},
 {'name':'eager-enclosing-local-positive','source':'Never=str\ndef outer():\n from typing import Never\n def f()->Never | int: ...\n return f\nf=outer()\n','bottom':True},
]
(out/'python-probes.json').write_text(json.dumps(probes,indent=2)+'\n')
reference=[{'rule':'RUF020','name':p['name'],'filename':'case.py','source':p['source']} for p in probes]
reference += [
 {'rule':'PYI020','name':'nested-quoted-stub','filename':'case.pyi','source':'Alias = list["\'T\'"]\n'},
 {'rule':'PYI020','name':'nested-quoted-python','filename':'case.py','source':'Alias = list["\'T\'"]\n'},
 {'rule':'PYI020','name':'nested-literal-value','filename':'case.pyi','source':'from typing import Literal\nAlias = list["Literal[\'T\']"]\n'},
 {'rule':'PYI020','name':'malformed-quoted-stub','filename':'case.pyi','source':'Alias = list["not valid Python"]\n'},
]
old=json.loads(Path('/tmp/remaining26-current-failed-case-index-20261103.json').read_text())
for row in old:
 if row['rule']=='RUF020':
  file,source=next(iter(row['files'].items()));reference.append({'rule':'RUF020','name':'original-'+row['name'],'filename':file,'source':source})
(out/'reference-inputs.json').write_text(json.dumps(reference,indent=2)+'\n')
