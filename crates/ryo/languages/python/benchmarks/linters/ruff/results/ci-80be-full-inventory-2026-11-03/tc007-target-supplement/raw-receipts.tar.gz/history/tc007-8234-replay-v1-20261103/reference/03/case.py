from typing import TYPE_CHECKING as TC, TypeAlias as TA
if TC:
 class Foo: ...
Alias:TA=Foo
