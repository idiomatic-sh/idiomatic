"%s" % {"x":value}
