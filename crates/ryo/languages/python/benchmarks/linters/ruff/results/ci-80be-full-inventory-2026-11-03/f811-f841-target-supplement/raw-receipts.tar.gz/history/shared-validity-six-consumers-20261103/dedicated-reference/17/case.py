def outer():
    value=1
    def inner():
        global value
        nonlocal value
