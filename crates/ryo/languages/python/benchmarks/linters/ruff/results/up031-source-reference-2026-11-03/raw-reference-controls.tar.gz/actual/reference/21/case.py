"%s" % [value]
