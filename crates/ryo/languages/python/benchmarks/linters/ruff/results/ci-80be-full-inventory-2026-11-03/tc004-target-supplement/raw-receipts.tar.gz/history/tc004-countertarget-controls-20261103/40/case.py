from typing import TYPE_CHECKING
if TYPE_CHECKING:
 from external import Foo
class C:
 def __getattr__(self,name): return 1
__all__=["Foo"]
