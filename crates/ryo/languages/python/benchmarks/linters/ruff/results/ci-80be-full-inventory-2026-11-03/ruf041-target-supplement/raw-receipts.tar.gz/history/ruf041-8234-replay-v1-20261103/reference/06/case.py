from typing import Literal
x=Literal[Literal[list[int],1]]
