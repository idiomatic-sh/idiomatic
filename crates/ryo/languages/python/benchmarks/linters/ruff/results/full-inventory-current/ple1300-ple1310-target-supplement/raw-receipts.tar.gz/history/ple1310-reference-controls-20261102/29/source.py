''.strip('aa', 'x')
