from typing import Optional
x: Optional["X"]
