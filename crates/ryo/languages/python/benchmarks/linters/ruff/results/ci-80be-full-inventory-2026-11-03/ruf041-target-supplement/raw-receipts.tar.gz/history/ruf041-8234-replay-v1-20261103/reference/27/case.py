from typing import Literal
type Alias[Literal]=Literal[Literal[1]]
