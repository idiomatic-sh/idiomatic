class C:
    other.__slots__ = ["z", "a"]
