''.strip('😀é')
