class C:
    x = __slots__ = ["z", "a"]
