'{:\x71}'.format(1)
