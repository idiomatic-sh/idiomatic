from typing import Generic, TypeVar, AnyStr
T = TypeVar("T")
Generic=list
class C(Generic[T]): ...
