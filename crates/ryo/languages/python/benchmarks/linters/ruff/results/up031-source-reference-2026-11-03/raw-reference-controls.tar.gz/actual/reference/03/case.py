"%s" % value
