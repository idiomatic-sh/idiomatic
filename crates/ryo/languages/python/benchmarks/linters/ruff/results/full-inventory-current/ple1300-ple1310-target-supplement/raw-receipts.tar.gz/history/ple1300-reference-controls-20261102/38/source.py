'%q' % 1  # noqa: F401
