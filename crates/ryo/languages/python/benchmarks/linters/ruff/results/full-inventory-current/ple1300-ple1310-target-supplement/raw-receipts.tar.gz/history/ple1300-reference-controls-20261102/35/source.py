'{:z.2f}'.format(-0.0)
