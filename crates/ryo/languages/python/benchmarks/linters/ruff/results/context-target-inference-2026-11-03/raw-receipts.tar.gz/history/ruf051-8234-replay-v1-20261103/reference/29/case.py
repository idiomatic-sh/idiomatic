d={}
if key in d: del d[key] # noqa: RUF051
