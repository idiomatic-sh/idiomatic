with {} as d:
 if key in d: del d[key]
