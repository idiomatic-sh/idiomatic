d:dict
if key in d: del d[key]
