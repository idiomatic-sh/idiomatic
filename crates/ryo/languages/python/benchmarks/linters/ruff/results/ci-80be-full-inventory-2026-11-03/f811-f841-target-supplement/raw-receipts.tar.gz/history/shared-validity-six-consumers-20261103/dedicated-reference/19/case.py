class C[T]:
 def f(self):
  global T
  nonlocal T
