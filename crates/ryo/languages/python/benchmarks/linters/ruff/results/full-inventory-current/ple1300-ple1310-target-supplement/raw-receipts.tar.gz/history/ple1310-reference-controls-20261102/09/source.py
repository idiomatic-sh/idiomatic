b''.strip(b'\x00\xffab')
