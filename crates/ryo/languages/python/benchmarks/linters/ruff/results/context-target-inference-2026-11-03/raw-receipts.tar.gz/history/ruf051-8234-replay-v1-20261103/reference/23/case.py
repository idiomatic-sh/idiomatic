d={}
if b"\xff" in d: del d[b"\377"]
