"%q" "%d" % value
