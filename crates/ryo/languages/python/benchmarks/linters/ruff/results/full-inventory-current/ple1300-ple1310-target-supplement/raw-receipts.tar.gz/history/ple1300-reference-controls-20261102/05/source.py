b'%b' % b'x'
