if text.startswith(""):
    text = text[0:]
