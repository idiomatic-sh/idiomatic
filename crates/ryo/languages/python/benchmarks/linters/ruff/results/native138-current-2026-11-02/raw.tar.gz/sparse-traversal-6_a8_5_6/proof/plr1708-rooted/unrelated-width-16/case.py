def f():
    yield outer(deep(1))
    def inner():
        yield 2
        raise StopIteration
    callback = lambda: (yield 3)
    annotation: "StopIteration"
    class C:
        raise StopIteration
    raise StopIteration
unrelated = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
