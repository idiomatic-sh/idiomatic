def outer[T]():
 def middle():
  T=1
  def inner():
   global T
   nonlocal T
