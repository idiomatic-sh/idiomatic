D=dict
d=D()
if key in d: del d[key]
