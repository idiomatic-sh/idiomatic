text.format(1)
