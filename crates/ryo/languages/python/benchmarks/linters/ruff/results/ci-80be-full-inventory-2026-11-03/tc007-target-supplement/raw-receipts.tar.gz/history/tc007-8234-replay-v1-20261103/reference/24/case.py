from typing import TYPE_CHECKING, TypeAlias
TYPE_CHECKING=True
if TYPE_CHECKING:
 class Foo: ...
Alias:TypeAlias=Foo
