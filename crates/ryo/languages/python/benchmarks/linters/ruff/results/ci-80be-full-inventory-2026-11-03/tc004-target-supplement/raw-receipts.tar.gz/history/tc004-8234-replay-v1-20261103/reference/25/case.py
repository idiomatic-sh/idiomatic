import typing as t
if t.TYPE_CHECKING:
 from external import Foo
x=Foo
