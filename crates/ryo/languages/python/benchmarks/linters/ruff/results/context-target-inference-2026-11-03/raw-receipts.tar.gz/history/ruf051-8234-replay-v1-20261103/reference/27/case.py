((d,),x)=(({},),0)
if key in d: del d[key]
