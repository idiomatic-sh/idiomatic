from typing import Literal
x=Literal[identity(Literal[Literal[1]])]
