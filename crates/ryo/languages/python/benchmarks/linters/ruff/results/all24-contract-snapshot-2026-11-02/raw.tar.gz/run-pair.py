"""Compare sealed pre-migration and mandatory-contract workers on frozen Django310."""
from pathlib import Path
import collections
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
import shutil
import signal
import subprocess
import time
import tomllib

source_root = Path('/tmp/django-numeric-sparse-full-20261102')
out = Path('/tmp/django-all24-baseline-candidate-pair-20261102')
out.mkdir(exist_ok=False)
source_manifest = json.loads((source_root / 'manifest.json').read_text())
files = json.loads((source_root / 'files.json').read_text())
base_request = json.loads((source_root / 'request.json').read_text())
normal_inventory = json.loads((source_root / 'source-inventory.json').read_text())
edited_inventory = json.loads((source_root / 'source-inventory-edited.json').read_text())
old_cold = json.loads((source_root / 'cold-report.json').read_text())
old_edited = json.loads((source_root / 'edit-retained-report.json').read_text())
patch = source_root / 'django.patch'
collector = Path(source_manifest['binaries']['collector']['path'])
validator = Path(source_manifest['validator']['path'])
workers = {
    'baseline': Path('/tmp/file-dag-execution-gate-20261102-3/python-release-sealed'),
    'candidate': Path('/tmp/all24-worker-release-20261102/python-release-sealed'),
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def verify_corpus(root, inventory):
    for item in inventory:
        path = root / item['file']
        if digest(path) != item['sha256'] or path.stat().st_mode & 0o777 != item['mode']:
            raise ValueError(f'corpus mismatch: {item["file"]}')


def native(value):
    return {'Unix': list(os.fsencode(value))}


def seconds(duration):
    return duration['secs'] + duration['nanos'] / 1e9


def multiset_delta(previous, current):
    key = lambda row: (row['rule'], row['file'], row['start'], row['end'])
    old = collections.Counter(map(key, previous['diagnostics']))
    new = collections.Counter(map(key, current['diagnostics']))
    return {'added_count': sum((new - old).values()), 'removed_count': sum((old - new).values()),
            'added_examples': list((new - old).elements())[:12],
            'removed_examples': list((old - new).elements())[:12]}


assert len(files) == 2875 and len(source_manifest['selection']) == 310
assert digest(collector) == source_manifest['binaries']['collector']['sha256']
assert digest(validator) == source_manifest['validator']['sha256']
assert digest(patch) == source_manifest['patch_sha256']
for relative, expected in source_manifest['profile_inputs'].items():
    assert digest(source_root / 'profile' / relative) == expected, relative
verify_corpus(source_root / 'corpus', edited_inventory)
spec = importlib.util.spec_from_file_location('frozen_validator', validator)
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
settings = v.canonical_run_ryo_settings(
    tomllib.loads((source_root / 'profile/benchmark.toml').read_text()),
    source_manifest['selection'], json.loads((source_root / 'phase-registry.json').read_text()),
)
manifest = {'schema': 'django-all24-baseline-candidate-pair/v1', 'measurement_kind': 'ordinary-scoped',
            'timing_observed': True,
            'scope': 'serial fresh-cache frozen Django310 comparison of sealed pre-migration and mandatory-contract workers; full acceptance open',
            'source_profile_manifest_sha256': digest(source_root / 'manifest.json'),
            'profile_sha256': digest(source_root / 'profile/benchmark.toml'),
            'files_sha256': digest(source_root / 'files.json'),
            'patch_sha256': digest(patch), 'collector_sha256': digest(collector),
            'validator_sha256': digest(validator),
            'workers': {name: {'path': str(path), 'sha256': digest(path)} for name, path in workers.items()},
            'corpus_files': len(files), 'rules': len(source_manifest['selection']),
            'rayon_threads': 1, 'phase_order': ['cold'],
            'default_strategy': 'RYO_FILE_DAG_EXECUTION=1 for both workers',
            'cache_semantics': 'independent fresh cache per variant; same hash-verified read-only normal corpus',
            'corpus_source': '/tmp/django-file-program-graph-pair-20261102/graph-on/corpus',
            'historical_goldens': {'cold_sha256': digest(source_root / 'cold-report.json'),
                                   'edited_sha256': digest(source_root / 'edit-retained-report.json')}}
write(out / 'manifest.json', manifest)

for name in workers:
    target = out / name
    target.mkdir()
    original_corpus = Path('/tmp/django-file-program-graph-pair-20261102/graph-on/corpus')
    verify_corpus(original_corpus, normal_inventory)
    (target / 'corpus').symlink_to(original_corpus, target_is_directory=True)
    verify_corpus(target / 'corpus', normal_inventory)


def run_phase(name, phase):
    target = out / name
    corpus = target / 'corpus'
    if phase == 'edit-retained':
        verify_corpus(corpus, normal_inventory)
        subprocess.run(['git', 'apply', str(patch)], cwd=corpus, check=True)
    verify_corpus(corpus, edited_inventory if phase.startswith('edit-') else normal_inventory)
    phase_dir = target / phase
    phase_dir.mkdir()
    cache = target / 'retained-cache' if phase != 'edit-fresh' else phase_dir / 'fresh-cache'
    expected_cache = phase in {'warm', 'edit-retained'}
    if cache.exists() != expected_cache:
        raise ValueError(f'cache phase mismatch: {name}/{phase}')
    request = dict(base_request, root=str(corpus), rules=str(source_root / 'profile/rules'), cache=str(cache))
    write(phase_dir / 'request.json', request)
    worker = workers[name]
    command = [str(worker), 'run-ryo', '--request-file', str(phase_dir / 'request.json'), 'python-target=3.10']
    wire = {'executable': native(command[0]), 'arguments': [native(arg) for arg in command[1:]],
            'environment': [{'name': native('RAYON_NUM_THREADS'), 'value': native('1')}, {'name': native('RYO_FILE_PROGRAM_GRAPH'), 'value': native('0')}, {'name': native('RYO_FILE_DAG_EXECUTION'), 'value': native('1')}],
            'directory': native(corpus)}
    write(phase_dir / 'collector-request.json', wire)
    started = time.monotonic()
    with (phase_dir / 'observation.json').open('wb') as stdout, (phase_dir / 'collector.stderr').open('wb') as stderr:
        child = subprocess.Popen([str(collector)], stdin=subprocess.PIPE, stdout=stdout, stderr=stderr,
                                 start_new_session=True)
        try:
            child.communicate(input=json.dumps(wire).encode(), timeout=600)
            capped = False
        except subprocess.TimeoutExpired:
            capped = True
            def descendants(pid):
                try:
                    children = [int(value) for value in Path(f'/proc/{pid}/task/{pid}/children').read_text().split()]
                except OSError:
                    return []
                return [nested for member in children for nested in descendants(member)] + children
            owned = descendants(child.pid)
            for pid in owned:
                try:
                    os.kill(pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
            try:
                child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                for pid in owned:
                    try:
                        os.kill(pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                child.kill()
                child.wait()
    receipt = {'variant': name, 'phase': phase, 'worker_sha256': digest(worker),
               'request_sha256': digest(phase_dir / 'request.json'),
               'collector_exit_code': child.returncode, 'capped': capped,
               'orchestration_wall_seconds': time.monotonic() - started,
               'observation_sha256': digest(phase_dir / 'observation.json')}
    if capped or child.returncode:
        write(phase_dir / 'result.json', receipt)
        raise ValueError(f'collector failed: {name}/{phase}')
    observed = json.loads((phase_dir / 'observation.json').read_text())
    if observed['result'] != 'Observed':
        raise ValueError(f'collector observation unavailable: {name}/{phase}')
    output = observed['output']
    raw_stdout = bytes(output['stdout'])
    raw_stderr = bytes(output['stderr'])
    (phase_dir / 'stdout.bin').write_bytes(raw_stdout)
    (phase_dir / 'stderr.bin').write_bytes(raw_stderr)
    report = v.complete_run_ryo_report(output['status'], raw_stdout.decode(), raw_stderr.decode(),
                                      files, source_manifest['selection'], request=request,
                                      settings=settings, expected_cache_path=cache)
    write(phase_dir / 'report.json', report)
    receipt.update(worker_exit_code=output['status'], wall_seconds=seconds(output['wall']),
                   cpu_seconds=seconds(output['cpu']), peak_rss_bytes=output['rss'],
                   report_sha256=digest(phase_dir / 'report.json'),
                   diagnostics=len(report['diagnostics']), coverage=report['coverage'],
                   historical_delta=multiset_delta(old_edited if phase.startswith('edit-') else old_cold, report))
    write(phase_dir / 'result.json', receipt)
    print(json.dumps(receipt), flush=True)
    return report


def resource_preflight():
    memory_root = Path('/sys/fs/cgroup')
    limit_text = (memory_root / 'memory.max').read_text().strip() if (memory_root / 'memory.max').exists() else 'max'
    current = int((memory_root / 'memory.current').read_text()) if (memory_root / 'memory.current').exists() else None
    stat = {}
    if (memory_root / 'memory.stat').exists():
        stat = {key: int(value) for key, value in (line.split() for line in (memory_root / 'memory.stat').read_text().splitlines())}
    limit = None if limit_text == 'max' else int(limit_text)
    reclaimable = stat.get('inactive_file', 0)
    available_kib = next(int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
    host_available = available_kib * 1024
    effective_headroom = host_available if limit is None or current is None else min(host_available, limit - current + reclaimable)
    observed_off_peak = json.loads(Path('/tmp/django-file-program-graph-pair-20261102/graph-off/cold/result.json').read_text())['peak_rss_bytes']
    required_memory = observed_off_peak + 512 * 1024 * 1024
    disk_free = shutil.disk_usage(out).free
    required_disk = 10 * 1024 * 1024 * 1024
    receipt = {'cgroup_limit': limit, 'cgroup_current': current, 'inactive_file': reclaimable, 'inactive_file_reclaim_is_estimate': True,
               'host_available': host_available, 'effective_headroom': effective_headroom, 'required_memory': required_memory,
               'disk_free': disk_free, 'required_disk': required_disk,
               'passed': disk_free >= required_disk and effective_headroom >= required_memory}
    write(out / 'resource-preflight.json', receipt)
    if not receipt['passed']:
        raise RuntimeError('resource preflight refused paired comparison')

resource_preflight()
rows = []
assert os.environ.get('RYO_COLUMN_KERNEL') not in {'1'}, 'default-only comparison requires kernel disabled'
assert digest(workers['baseline']) != digest(workers['candidate'])
with Path('/workspaces/.cargo-build.lock').open('a+') as local_lock:
    fcntl.flock(local_lock, fcntl.LOCK_EX)
    results = {}
    for name in workers:
        results[name] = run_phase(name, 'cold')
        rows.append(json.loads((out / name / 'cold' / 'result.json').read_text()))
    exact = results['baseline'] == results['candidate']
    write(out / 'summary.json', {'status': 'complete' if exact else 'report-difference',
                                  'rows': rows, 'same_report_exact': exact,
                                  'delta': multiset_delta(results['baseline'], results['candidate'])})
    if not exact:
        raise SystemExit(1)
