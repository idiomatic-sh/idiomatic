"%#0- +10x" % value
