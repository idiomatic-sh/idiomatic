from typing import TYPE_CHECKING, TypeAlias
def outer():
 if TYPE_CHECKING:
  from external import int
 Alias:TypeAlias=int
