from typing import TYPE_CHECKING as TC
if TC:
 from external import Foo
x=Foo
