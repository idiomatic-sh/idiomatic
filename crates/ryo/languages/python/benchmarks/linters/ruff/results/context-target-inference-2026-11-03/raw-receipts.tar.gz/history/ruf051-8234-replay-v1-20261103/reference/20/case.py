d={}
if -1 in d: del d[-1]
