from typing import TYPE_CHECKING, TypeAlias
if TYPE_CHECKING:
 class Foo: ...
from typing import Literal
Alias:TypeAlias=Literal[Foo]
