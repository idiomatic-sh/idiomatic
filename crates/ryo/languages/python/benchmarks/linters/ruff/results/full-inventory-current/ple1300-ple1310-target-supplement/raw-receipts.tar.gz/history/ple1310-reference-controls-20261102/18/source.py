text = b''
text.rstrip(b'aa')
