from typing import Literal
x=Literal["Literal[Literal[1]]"]
