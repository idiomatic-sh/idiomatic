d=dict()
def f():
 if key in d: del d[key]
dict=custom
