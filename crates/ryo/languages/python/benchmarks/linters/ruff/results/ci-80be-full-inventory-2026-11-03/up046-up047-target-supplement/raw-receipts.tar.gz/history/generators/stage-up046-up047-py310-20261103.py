from pathlib import Path
import shutil,json,sys,tomllib
r=Path('/tmp/up046-up047-source-20261103/crates/ryo/languages/python/benchmarks/linters/ruff');sys.path.insert(0,str(r));from authoring.profile_sources import write_staged_profile,assert_staged_profile_fixed_point
observations=json.loads(Path('/tmp/up046-up047-reference-controls-20261103/results.json').read_text())
for rule in ['UP046','UP047']:
 source=Path('/tmp/up046-up047-source-stage-v3-20261103/profiles')/rule/'repro';dest=Path('/tmp/up046-up047-countertarget-stage-v3-20261103')/rule;shutil.copytree(source,dest)
 profile=tomllib.loads((dest/'benchmark.toml').read_text());write_staged_profile(dest/'benchmark.toml',dest/'benchmark.toml',profile['query-modules'],'python-target=3.10',{rule:'accepted-syntax'},module_root=dest)
 path=dest/'rules'/rule/'cases.toml';cases=tomllib.loads(path.read_text())['cases'];lines=[]
 for c in cases:
  name=c['name'].removeprefix('upstream-');row=next(z for z in observations if z['rule']==rule and z['case']==name and z['target']=='py310');file,src=next(iter(c['files'].items()));expected=[]
  for diag in row['diagnostics']:
   offsets=[];ss=src.splitlines(keepends=True)
   for k in ['location','end_location']:
    l=diag[k];offsets.append(len(''.join(ss[:l['row']-1]).encode())+len(ss[l['row']-1][:l['column']-1].encode()))
   expected.append({'rule':diag['code'],'file':file,'start':offsets[0],'end':offsets[1]})
  lines+=['[[cases]]','name = '+json.dumps(c['name']),'files = { '+json.dumps(file)+' = '+json.dumps(src)+' }','expected = ['+', '.join('{ '+', '.join(k+' = '+json.dumps(v) for k,v in f.items())+' }' for f in expected)+']','']
 path.write_text('\n'.join(lines));assert_staged_profile_fixed_point(dest);print(dest)
