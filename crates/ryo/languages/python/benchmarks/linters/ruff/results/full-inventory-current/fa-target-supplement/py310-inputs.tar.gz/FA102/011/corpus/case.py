from __future__ import annotations
x: list[int]
