from typing_extensions import Literal as L
x=L[L[1]]
