x: int | str
