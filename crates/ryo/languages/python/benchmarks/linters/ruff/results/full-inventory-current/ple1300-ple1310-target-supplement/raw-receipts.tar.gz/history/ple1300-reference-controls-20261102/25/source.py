text = '{:q}'
text.format(1)
