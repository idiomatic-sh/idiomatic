d:dict
d={}
if key in d: del d[key]
