class C((value:=object)):
 global value
 nonlocal value
