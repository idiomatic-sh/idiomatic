def f[T]():
 global T
 nonlocal T
