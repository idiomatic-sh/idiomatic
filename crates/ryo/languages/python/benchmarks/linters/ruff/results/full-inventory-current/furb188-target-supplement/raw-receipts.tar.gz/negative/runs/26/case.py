if text.startswith("a"):
    text = text[1:]
else:
    pass
