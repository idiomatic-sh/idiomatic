d={}
if b"ab" in d: del d["ab"]
