from typing import Union
x: Union[*types]
