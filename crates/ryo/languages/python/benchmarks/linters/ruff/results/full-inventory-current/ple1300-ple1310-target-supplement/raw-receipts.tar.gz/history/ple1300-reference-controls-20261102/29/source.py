f'{{:q}}'.format(1)
