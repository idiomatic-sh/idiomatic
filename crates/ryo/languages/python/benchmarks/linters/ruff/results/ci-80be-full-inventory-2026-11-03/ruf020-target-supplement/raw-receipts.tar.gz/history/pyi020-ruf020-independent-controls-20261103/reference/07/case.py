from __future__ import annotations
Never=str
def outer():
 from typing import Never
 def f()->Never | int: ...
 return f
f=outer()
