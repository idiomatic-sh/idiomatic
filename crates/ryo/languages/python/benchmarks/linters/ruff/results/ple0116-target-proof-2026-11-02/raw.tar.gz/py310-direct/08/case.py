while True:
    try:
        pass
    finally:
        def inner():
            while True:
                continue
