b''.strip(b'\x01\x10')
