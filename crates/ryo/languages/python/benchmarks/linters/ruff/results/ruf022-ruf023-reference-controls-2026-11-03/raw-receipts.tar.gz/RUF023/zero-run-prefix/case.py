class C:
    __slots__ = ["x010", "x01"]
