def f(d:dict):
 if key in d: del d[key]
dict=custom
import builtins
