from typing import Generic, TypeVar, AnyStr
T = TypeVar("T")
def f(x:T): ... # noqa: UP047
