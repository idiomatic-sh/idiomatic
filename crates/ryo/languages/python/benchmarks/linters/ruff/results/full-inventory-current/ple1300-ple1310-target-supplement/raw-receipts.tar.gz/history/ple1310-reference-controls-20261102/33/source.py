''.removesuffix('aa')
