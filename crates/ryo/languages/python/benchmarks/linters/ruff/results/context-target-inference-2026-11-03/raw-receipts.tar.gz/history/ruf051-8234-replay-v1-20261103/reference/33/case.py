d={}
if 1.00j in d: del d[1e0j]
