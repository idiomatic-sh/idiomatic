b''.strip('aa')
