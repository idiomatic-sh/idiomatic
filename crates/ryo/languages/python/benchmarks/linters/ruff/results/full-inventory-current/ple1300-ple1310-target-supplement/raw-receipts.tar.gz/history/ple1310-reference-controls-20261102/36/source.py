# ruff: noqa: PLE1310
b''.strip(b'aa')
