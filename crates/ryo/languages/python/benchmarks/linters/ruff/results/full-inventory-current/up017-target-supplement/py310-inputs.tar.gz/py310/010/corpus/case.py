import datetime
datetime.timezone.utc  # noqa: UP017
