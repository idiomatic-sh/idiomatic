def f(len):
    if text.startswith(prefix):
        text = text[len(prefix):]
