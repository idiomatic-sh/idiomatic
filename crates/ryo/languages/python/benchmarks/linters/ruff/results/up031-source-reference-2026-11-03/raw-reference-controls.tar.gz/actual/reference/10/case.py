"%10s" % value
