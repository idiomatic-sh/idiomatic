from typing import TYPE_CHECKING, TypeAlias
if TYPE_CHECKING:
 from external import int
Alias:TypeAlias=int
