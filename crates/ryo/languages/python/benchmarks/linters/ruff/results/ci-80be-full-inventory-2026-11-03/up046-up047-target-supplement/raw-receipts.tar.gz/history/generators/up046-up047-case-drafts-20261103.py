from pathlib import Path
import json,re,hashlib
root=Path('/tmp/up046-up047-source-20261103/crates/ryo/languages/python/benchmarks/linters/ruff');e=Path('/tmp/up046-up047-reference-controls-20261103');rows=json.loads((e/'results.json').read_text())
positive={'UP046':{'positive','alias','qualified','external','not-last'},'UP047':{'positive','alias','anystr','repeated','async'}}
for rule in ['UP046','UP047']:
 d=root/'rules'/rule;d.mkdir(exist_ok=True)
 lines=['# Full pinned fixtures retained; controls specify spans from declaration tokens.','']
 manifest=[]
 for row in rows:
  if row['rule']!=rule or row['target']!='py312':continue
  name=row['case'];src=(e/rule/name/'case.py').read_text();upstream=name.endswith('.py');file=name if upstream else 'case.py'
  expected=[]
  if upstream:
   for diag in row['diagnostics']:
    offsets=[]
    for key in ['location','end_location']:
     loc=diag[key];ls=src.splitlines(keepends=True);offsets.append(len(''.join(ls[:loc['row']-1]).encode())+len(ls[loc['row']-1][:loc['column']-1].encode()))
    expected.append({'rule':diag['code'],'file':file,'start':offsets[0],'end':offsets[1]})
  elif name in positive[rule]:
   if rule=='UP046':
    start=src.index('(',src.index('class C'))+1;end=src.index(']',start)+1
   else:
    m=re.search(r'def (f)\(',src);start=m.start(1);end=src.index(')',m.end())+1
   expected=[{'rule':rule,'file':file,'start':len(src[:start].encode()),'end':len(src[:end].encode())}]
  actual=[]
  for q in row['diagnostics']:
   offsets=[]
   for k in ['location','end_location']:
    l=q[k];ss=src.splitlines(keepends=True);offsets.append(len(''.join(ss[:l['row']-1]).encode())+len(ss[l['row']-1][:l['column']-1].encode()))
   actual.append({'rule':q['code'],'file':file,'start':offsets[0],'end':offsets[1]})
  assert actual==expected,(rule,name,actual,expected)
  lines += ['[[cases]]','name = '+json.dumps(('upstream-' if upstream else '')+name),'files = { '+json.dumps(file)+' = '+json.dumps(src)+' }','expected = ['+', '.join('{ '+', '.join(k+' = '+json.dumps(v) for k,v in f.items())+' }' for f in expected)+']','']
  manifest.append({'name':name,'source_sha256':hashlib.sha256(src.encode()).hexdigest(),'expected':expected,'expectation_basis':'pinned full fixture' if upstream else 'independent exact declaration token interval'})
 (d/'cases.toml').write_text('\n'.join(lines))
 profile=root/'profiles'/rule;profile.mkdir(exist_ok=True)
 settings=(root/'profiles/UP049/benchmark.toml').read_text().replace('UP049',rule).replace('python-target=3.13','python-target=3.12');(profile/'benchmark.toml').write_text(settings)
 (d/'README.md').write_text(f'# {rule}\n\nSource draft using existing Python semantic, binding and target facts. No candidate correctness claim until actual shared-runner replay.\n\nCanonical profile targets Python 3.12, the first version supporting PEP 695; Python 3.10 countertarget must execute separately. Full pinned Ruff 0.16.5 fixtures are preserved in cases.toml. Independent controls cover aliases, shadowing, nesting, defaults, suppression and exact spans.\n')
 (e/(rule+'-expectation-origins.json')).write_text(json.dumps(manifest,indent=2)+'\n')
 print(rule,len(manifest),'cases')
