from typing import Literal
x=bool(other=Literal[Literal[1]])
