unrelated = f"{value}"
if text.startswith("a"):
    text = text[1:]
