class C:
    __slots__ = ["item01", "item1"]
