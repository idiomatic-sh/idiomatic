def f(d:dict):
 if key in d: del d[key]
def g():
 import builtins
dict=custom
