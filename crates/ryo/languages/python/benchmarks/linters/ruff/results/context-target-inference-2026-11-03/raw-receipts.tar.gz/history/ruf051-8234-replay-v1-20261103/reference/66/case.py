from __future__ import annotations
import builtins
def f[dict](d:dict):
 if key in d: del d[key]
