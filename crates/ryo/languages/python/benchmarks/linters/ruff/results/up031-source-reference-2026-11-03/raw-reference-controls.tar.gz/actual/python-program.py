import json,sys
rows=[]
def check(name,left,right):
 assert left==right,(name,left,right);rows.append({'name':name,'left':left,'right':right,'passed':True})
check('combined_flags_preserve_semantics',"%#0- +10x" % 42,"% #+-010x" % 42)
check('repeated_flags_are_idempotent',"%##00--++  10x" % 42,"% #+-010x" % 42)
check('repr_flag_presence_is_not_precedence',"%+r" % 3,"%r" % 3)
check('escaped_percent_is_runtime_percent',"\x25s" % 'x','x')
check('literal_percent_escape',"%%" % (),"%")
check('plain_conversion',"%s" % 'x',"x")
json.dump({'python':sys.version,'results':rows},sys.stdout,indent=2)
