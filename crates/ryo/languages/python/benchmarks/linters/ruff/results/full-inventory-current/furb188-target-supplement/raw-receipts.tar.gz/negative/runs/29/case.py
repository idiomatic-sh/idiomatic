if text.strip("a"):
    text = text[1:]
