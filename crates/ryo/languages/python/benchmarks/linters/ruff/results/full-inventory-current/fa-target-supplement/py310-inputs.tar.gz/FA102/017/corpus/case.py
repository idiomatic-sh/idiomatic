import queue
x: queue.Queue[int]
