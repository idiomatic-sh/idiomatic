class C:
 from __future__ import annotations
 def f(x:(value:=object)): pass
def later(x:(other:=object)): pass
