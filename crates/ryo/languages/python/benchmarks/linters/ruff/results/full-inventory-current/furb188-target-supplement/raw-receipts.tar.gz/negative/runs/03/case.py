result = text[3:] if text.startswith("pre") else text
