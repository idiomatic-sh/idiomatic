text = 'aa'
''.strip(text)
