from typing import Literal
Alias = list["Literal['T']"]
