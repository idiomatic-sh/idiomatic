def f(str):
    text = str()
    text.strip('aa')
