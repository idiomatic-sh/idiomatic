d={}
if "a" "b" in d: del d["ab"]
