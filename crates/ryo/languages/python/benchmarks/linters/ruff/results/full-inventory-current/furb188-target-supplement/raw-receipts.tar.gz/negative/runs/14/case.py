if other.startswith("pre"):
    text = text[3:]
