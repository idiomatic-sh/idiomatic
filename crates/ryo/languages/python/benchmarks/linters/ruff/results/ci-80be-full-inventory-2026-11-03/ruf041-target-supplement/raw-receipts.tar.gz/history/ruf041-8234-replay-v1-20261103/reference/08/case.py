from typing import Literal
x=list[Literal[Literal[1]]]
