from datetime import timezone
timezone.utc
