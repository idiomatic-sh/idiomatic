'{x:q}'.format_map({'x':1})
