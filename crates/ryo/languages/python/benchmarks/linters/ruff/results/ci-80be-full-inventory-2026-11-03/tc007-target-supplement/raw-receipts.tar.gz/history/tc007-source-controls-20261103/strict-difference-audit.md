# TC007 first strict differences

Unchanged intended rule contract: valid PEP613 explicit type aliases in runtime module/class scope; resolved type-expression names unavailable at runtime because their known bindings are type-checking-only. Ordinary undefined-name errors, unsupported typing contexts and arbitrary value-expression errors are not automatically TC007 bugs. No certificate or expectation change yet.

Primary scope basis: https://peps.python.org/pep-0613/#scope-restrictions . Function-local explicit TypeAlias declarations are invalid typing scope, even though Python parses them; CPython NameError alone does not establish a TC007 reference defect.

## annotation-only-name

```python
from typing import TYPE_CHECKING, TypeAlias
Foo:int
Alias:TypeAlias=Foo
```

Draft intended: `[{"rule": "TC007", "file": "case.py", "start": 68, "end": 71}]`

Observed pinned reference: `[]`

Independent runtime: `{"name": "annotation-only-name", "error": "NameError", "message": "name 'Foo' is not defined", "passed": true}`

## forward-runtime-class

```python
from typing import TYPE_CHECKING, TypeAlias
Alias:TypeAlias=Foo
class Foo: ...
```

Draft intended: `[{"rule": "TC007", "file": "case.py", "start": 60, "end": 63}]`

Observed pinned reference: `[]`

Independent runtime: `{"name": "forward-runtime-class", "error": "NameError", "message": "name 'Foo' is not defined", "passed": true}`

## function-local-builtin-shadow

```python
from typing import TYPE_CHECKING, TypeAlias
def outer():
 if TYPE_CHECKING:
  from external import int
 Alias:TypeAlias=int
```

Draft intended: `[{"rule": "TC007", "file": "case.py", "start": 120, "end": 123}]`

Observed pinned reference: `[]`

Independent runtime: `{"name": "function-local-builtin-shadow", "error": "UnboundLocalError", "message": "local variable 'int' referenced before assignment", "passed": true}`

## function-local-shadow

```python
from typing import TYPE_CHECKING, TypeAlias
class Foo: ...
def outer():
 if TYPE_CHECKING:
  from external import Foo
 Alias:TypeAlias=Foo
```

Draft intended: `[{"rule": "TC007", "file": "case.py", "start": 135, "end": 138}]`

Observed pinned reference: `[]`

Independent runtime: `{"name": "function-local-shadow", "error": "UnboundLocalError", "message": "local variable 'Foo' referenced before assignment", "passed": true}`

## runtime-fallback-deleted

```python
from typing import TYPE_CHECKING, TypeAlias
class Foo: ...
del Foo
if TYPE_CHECKING:
 from external import Foo
Alias:TypeAlias=Foo
```

Draft intended: `[{"rule": "TC007", "file": "case.py", "start": 127, "end": 130}]`

Observed pinned reference: `[]`

Independent runtime: `{"name": "runtime-fallback-deleted", "error": "NameError", "message": "name 'Foo' is not defined", "passed": true}`

## shadowed-true-guard

```python
from typing import TYPE_CHECKING, TypeAlias
TYPE_CHECKING=True
if TYPE_CHECKING:
 class Foo: ...
Alias:TypeAlias=Foo
```

Draft intended: `[]`

Observed pinned reference: `[{"cell": null, "code": "TC007", "end_location": {"column": 20, "row": 5}, "filename": "/tmp/tc007-8234-replay-v1-20261103/reference/24/case.py", "fix": {"applicability": "unsafe", "edits": [{"content": "\"Foo\"", "end_location": {"column": 20, "row": 5}, "location": {"column": 17, "row": 5}}], "message": "Add quotes"}, "location": {"column": 17, "row": 5}, "message": "Add quotes to type alias", "name": "unquoted-type-alias", "noqa_row": 5, "severity": "error", "url": "https://docs.astral.sh/ruff/rules/unquoted-type-alias"}]`

Independent runtime: `{"name": "shadowed-true-guard", "error": null, "passed": true}`
