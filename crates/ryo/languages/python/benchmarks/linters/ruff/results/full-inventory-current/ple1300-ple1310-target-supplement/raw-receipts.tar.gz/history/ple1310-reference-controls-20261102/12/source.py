''.strip('')
