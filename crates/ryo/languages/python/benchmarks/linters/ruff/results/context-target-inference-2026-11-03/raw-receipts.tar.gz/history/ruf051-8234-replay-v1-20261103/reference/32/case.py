d={}
if 1.00 in d: del d[1e0]
