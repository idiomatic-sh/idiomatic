'{:' 'q}'.format(1)
