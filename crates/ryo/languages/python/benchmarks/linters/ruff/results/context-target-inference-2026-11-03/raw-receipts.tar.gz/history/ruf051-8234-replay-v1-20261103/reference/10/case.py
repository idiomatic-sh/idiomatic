d={}
if key in d: del d[key]
elif flag: pass
