class C:
    __slots__ = ["\x7a", "a"]
