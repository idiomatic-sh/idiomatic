if text.startswith("pre"):
    text = text[2:]
