def outer():
 value:int
 def f():
  global value
  nonlocal value
