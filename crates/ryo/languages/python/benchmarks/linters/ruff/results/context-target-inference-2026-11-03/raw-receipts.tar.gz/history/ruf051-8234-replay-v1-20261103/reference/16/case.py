d={}
if True in d: del d[True]
