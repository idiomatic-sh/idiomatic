def early(x:(value:=object)): pass
from __future__ import annotations
def later(x:(other:=object)): pass
