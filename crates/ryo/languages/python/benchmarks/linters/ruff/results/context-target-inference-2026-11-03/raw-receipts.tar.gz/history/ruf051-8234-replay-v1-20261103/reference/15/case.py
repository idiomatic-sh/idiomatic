d={}
if ... in d: del d[...]
