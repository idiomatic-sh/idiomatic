d={}
if b"a" b"b" in d: del d[b"ab"]
