if text.startswith("pre"):
    other = text[3:]
