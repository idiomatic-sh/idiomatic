value = outer(deep(leaf(a)), shallow(b))
