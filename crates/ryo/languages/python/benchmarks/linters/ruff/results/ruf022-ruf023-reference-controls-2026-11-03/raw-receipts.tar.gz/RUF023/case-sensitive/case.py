class C:
    __slots__ = ["lower", "Class", "CONSTANT"]
