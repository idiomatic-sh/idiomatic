d:object={}
if key in d: del d[key]
