def f():
    __all__ = ["z", "a"]
