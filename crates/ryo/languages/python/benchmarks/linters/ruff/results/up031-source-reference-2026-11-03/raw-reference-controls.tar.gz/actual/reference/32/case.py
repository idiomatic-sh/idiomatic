"%s" % value # noqa: UP031
