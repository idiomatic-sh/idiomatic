class C:
    __slots__ = ["same", "same"]
