class C:
    __all__ = ["z", "a"]
