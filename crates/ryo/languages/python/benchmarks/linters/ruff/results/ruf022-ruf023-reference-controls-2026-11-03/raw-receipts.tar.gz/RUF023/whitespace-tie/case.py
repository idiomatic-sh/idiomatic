class C:
    __slots__ = ["a1", "a 1"]
