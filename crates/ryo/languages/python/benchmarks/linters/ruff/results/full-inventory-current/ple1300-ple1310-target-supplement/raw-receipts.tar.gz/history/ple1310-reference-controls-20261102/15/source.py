''.strip(b'aa')
