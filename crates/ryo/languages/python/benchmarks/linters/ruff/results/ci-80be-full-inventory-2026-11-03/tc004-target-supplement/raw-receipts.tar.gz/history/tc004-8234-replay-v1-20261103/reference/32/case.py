from typing import TYPE_CHECKING
if TYPE_CHECKING:
 import external
x=external.foo
