from __future__ import annotations
Literal:object
def outer():
 from typing import Literal
 def f()->Literal[Literal[1]]: ...
