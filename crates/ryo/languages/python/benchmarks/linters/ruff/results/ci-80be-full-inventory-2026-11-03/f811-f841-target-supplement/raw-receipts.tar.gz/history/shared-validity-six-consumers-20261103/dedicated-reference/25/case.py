def outer():
 nonlocal value
 def f():
  global value
  nonlocal value
