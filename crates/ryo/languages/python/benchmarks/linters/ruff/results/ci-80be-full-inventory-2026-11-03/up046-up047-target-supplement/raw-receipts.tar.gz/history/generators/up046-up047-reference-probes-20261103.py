import pathlib,json,subprocess,hashlib
out=pathlib.Path('/tmp/up046-up047-reference-controls-20261103');out.mkdir(exist_ok=True)
ruff='/home/vscode/.local/bin/ruff'; fixtures=pathlib.Path('/tmp/ruff-0165-src/crates/ruff_linter/resources/test/fixtures/pyupgrade')
shared='from typing import Generic, TypeVar, AnyStr\nT = TypeVar("T")\n'
controls={
'UP046':{'positive':shared+'class C(Generic[T]): ...\n','alias':'from typing import Generic as G, TypeVar as V\nT=V("T")\nclass C(G[T]): ...\n','qualified':'import typing as t\nT=t.TypeVar("T")\nclass C(t.Generic[T]): ...\n','shadow-generic':shared+'Generic=list\nclass C(Generic[T]): ...\n','duplicate':shared+'class C(Generic[T,T]): ...\n','default':'from typing_extensions import Generic, TypeVar\nT=TypeVar("T", default=int)\nclass C(Generic[T]): ...\n','external':'from typing import Generic\nfrom elsewhere import T\nclass C(Generic[T]): ...\n','nested':shared+'def f():\n class C(Generic[T]): ...\n','suppressed':shared+'class C(Generic[T]): ... # noqa: UP046\n','already-pep695':shared+'class C[S](Generic[T]): ...\n','not-last':shared+'class C(Generic[T,T], object): ...\n'},
'UP047':{'positive':shared+'def f(x:T)->T: ...\n','return-only':shared+'def f()->T: ...\n','string-annotation':shared+'def f(x:"T"): ...\n','alias':'from typing import TypeVar as V\nT=V("T")\ndef f(x:T): ...\n','anystr':'from typing import AnyStr\ndef f(x:AnyStr): ...\n','shadow-anystr':'from typing import AnyStr\nstr=1\ndef f(x:AnyStr): ...\n','default':'from typing_extensions import TypeVar\nT=TypeVar("T",default=int)\ndef f(x:T): ...\n','nested':shared+'def outer():\n def f(x:T): ...\n','method':shared+'class C:\n def f(self,x:T): ...\n','suppressed':shared+'def f(x:T): ... # noqa: UP047\n','already-pep695':shared+'def f[S](x:T): ...\n','shadow-typevar':'TypeVar=list\nT=TypeVar("T")\ndef f(x:T): ...\n','repeated':shared+'def f(x:T,y:T): ...\n','async':shared+'async def f(x:T): ...\n'}}
results=[]
for rule,items in controls.items():
 entries={p.name:p.read_text() for p in sorted(fixtures.glob(rule+'*.py'))};entries.update(controls[rule])
 for name,source in entries.items():
  d=out/rule/name;d.mkdir(parents=True,exist_ok=True);f=d/'case.py';f.write_text(source)
  for target in ['py312','py310']:
   args=[ruff,'check','--isolated','--target-version',target,'--select',rule,'--output-format','json',str(f)]
   p=subprocess.run(args,capture_output=True);(d/(target+'.json')).write_bytes(p.stdout);(d/(target+'.stderr')).write_bytes(p.stderr)
   results.append({'rule':rule,'case':name,'target':target,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'exit':p.returncode,'diagnostics':json.loads(p.stdout)})
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');(out/'invocation.json').write_text(json.dumps({'ruff_sha256':hashlib.sha256(pathlib.Path(ruff).read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'targets':['py312','py310'],'invocations':len(results)},indent=2)+'\n')
for r in results:
 if r['target']=='py312':print(r['rule'],r['case'],len(r['diagnostics']),[(d['code'],d['location'],d['end_location']) for d in r['diagnostics']][:2])
