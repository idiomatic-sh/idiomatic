if text.endswith(".txt"):
    text = text[:-4]
