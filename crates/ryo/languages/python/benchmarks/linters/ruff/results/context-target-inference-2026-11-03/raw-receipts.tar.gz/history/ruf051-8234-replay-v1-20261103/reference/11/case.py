d={}
if key not in d: del d[key]
