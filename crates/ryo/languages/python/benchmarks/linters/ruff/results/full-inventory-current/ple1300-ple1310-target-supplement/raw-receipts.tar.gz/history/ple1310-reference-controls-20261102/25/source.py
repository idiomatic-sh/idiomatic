''.strip(f'aa')
