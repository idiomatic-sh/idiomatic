("%s") % value
