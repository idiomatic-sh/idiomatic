from typing import TYPE_CHECKING
if TYPE_CHECKING:
 from external import Foo
type Alias=Foo
