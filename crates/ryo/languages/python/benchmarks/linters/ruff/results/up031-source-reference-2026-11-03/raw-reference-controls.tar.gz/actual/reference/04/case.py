"%.2f" % value
