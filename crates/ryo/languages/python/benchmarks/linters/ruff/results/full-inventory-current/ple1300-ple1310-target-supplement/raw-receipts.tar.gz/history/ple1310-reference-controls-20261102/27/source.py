('a' + 'b').strip('aa')
