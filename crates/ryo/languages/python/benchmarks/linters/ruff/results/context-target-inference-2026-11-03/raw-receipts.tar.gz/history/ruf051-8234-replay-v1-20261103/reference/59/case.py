from __future__ import annotations
def outer(d:dict):
 class C:
  if key in d: del d[key]
 dict=custom
