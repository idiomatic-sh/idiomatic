from typing import TYPE_CHECKING, TypeAlias
if TYPE_CHECKING:
 from typing import Literal
Alias:TypeAlias=Literal["x"]
