''.strip('😀é😀')
