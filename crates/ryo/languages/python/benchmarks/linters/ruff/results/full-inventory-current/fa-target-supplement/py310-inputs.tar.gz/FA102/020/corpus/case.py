x: list[int] # noqa: FA102
