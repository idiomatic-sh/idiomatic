from typing import Literal
Literal=custom
x=Literal[Literal[1]]
