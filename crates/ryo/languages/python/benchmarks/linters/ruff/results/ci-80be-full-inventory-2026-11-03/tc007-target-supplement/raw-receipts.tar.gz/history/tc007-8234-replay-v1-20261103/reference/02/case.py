from typing import TYPE_CHECKING, TypeAlias
if TYPE_CHECKING:
 from external import Foo
Alias:TypeAlias=Foo
