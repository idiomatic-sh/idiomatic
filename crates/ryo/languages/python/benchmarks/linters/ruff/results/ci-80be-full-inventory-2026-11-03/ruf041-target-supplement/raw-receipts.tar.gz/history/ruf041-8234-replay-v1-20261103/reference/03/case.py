from typing import Literal
x=Literal[Literal[()]]
