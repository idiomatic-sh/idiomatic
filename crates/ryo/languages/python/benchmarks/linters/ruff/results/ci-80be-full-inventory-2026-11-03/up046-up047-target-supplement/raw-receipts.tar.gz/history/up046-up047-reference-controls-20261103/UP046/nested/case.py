from typing import Generic, TypeVar, AnyStr
T = TypeVar("T")
def f():
 class C(Generic[T]): ...
