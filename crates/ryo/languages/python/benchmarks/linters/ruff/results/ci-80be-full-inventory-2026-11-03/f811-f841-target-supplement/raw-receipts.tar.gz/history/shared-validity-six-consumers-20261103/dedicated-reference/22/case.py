def outer():
 value=1
 del value
 def f():
  global value
  nonlocal value
