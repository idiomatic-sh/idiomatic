from __future__ import annotations
import typing
def f(d:typing.Dict):
 if key in d: del d[key]
typing=custom
