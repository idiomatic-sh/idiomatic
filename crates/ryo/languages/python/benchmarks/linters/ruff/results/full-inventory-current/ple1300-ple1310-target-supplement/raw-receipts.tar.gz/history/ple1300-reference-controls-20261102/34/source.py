'{:²d}'.format(1)
