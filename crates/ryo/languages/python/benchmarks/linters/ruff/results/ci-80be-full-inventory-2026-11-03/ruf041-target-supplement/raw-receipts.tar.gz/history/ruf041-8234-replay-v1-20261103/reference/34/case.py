from __future__ import annotations
def outer():
 from typing import Literal as list
 def f[list]()->list[list[1]]: ...
