def f(x:(value:=object)):
 global value
 nonlocal value
