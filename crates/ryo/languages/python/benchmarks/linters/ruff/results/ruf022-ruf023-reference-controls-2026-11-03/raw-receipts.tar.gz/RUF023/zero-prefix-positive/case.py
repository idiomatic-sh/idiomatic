class C:
    __slots__ = ["item1", "item01"]
