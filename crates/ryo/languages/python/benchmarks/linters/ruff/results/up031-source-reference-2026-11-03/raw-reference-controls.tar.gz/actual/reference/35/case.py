"%s" % ("%s" % value,)
