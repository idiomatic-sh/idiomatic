from typing import Generic, TypeVar, AnyStr
T = TypeVar("T")
class C:
 def f(self,x:T): ...
