from pathlib import Path
import subprocess,json,hashlib,tomllib,tempfile,os
out=Path(__file__).parent;root=Path('/tmp/up034-yield-token-followup-20261103/crates/ryo/languages/python/benchmarks/linters/ruff');ruff=Path('/home/vscode/.local/bin/ruff').resolve();results=[]
for target,path in [('py310',root/'rules/UP034/cases.toml'),('py314',root/'profiles/UP034-py314/cases.toml')]:
 for case in tomllib.loads(path.read_text())['cases']:
  with tempfile.TemporaryDirectory() as temp:
   cwd=Path(temp)
   for name,source in case['files'].items():
    p=cwd/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(source)
   command=[str(ruff),'check','--isolated','--select','UP034','--target-version',target,'--output-format','json','--',*case['files']];env=os.environ.copy();env['RAYON_NUM_THREADS']='1'
   child=subprocess.Popen(command,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);pid=child.pid;stdout,stderr=child.communicate(timeout=10)
   dest=out/target/case['name'];dest.mkdir(parents=True,exist_ok=True);(dest/'stdout.bin').write_bytes(stdout);(dest/'stderr.bin').write_bytes(stderr);(dest/'case.json').write_text(json.dumps(case,indent=2,ensure_ascii=False)+'\n')
   findings=[]
   if child.returncode in (0,1):
    for finding in json.loads(stdout):
     name=str(Path(finding['filename']).relative_to(cwd));source=case['files'][name];lines=source.splitlines(keepends=True)
     def offset(location):return len(''.join(lines[:location['row']-1]).encode())+len(lines[location['row']-1][:location['column']-1].encode())
     findings.append(dict(rule=finding['code'],file=name,start=offset(finding['location']),end=offset(finding['end_location'])))
   record=dict(name=case['name'],target=target,command=command,cwd=str(cwd),pid=pid,exit=child.returncode,expected=case['expected'],observed=findings,exact=child.returncode in (0,1) and findings==case['expected'],reference_sha256=hashlib.sha256(ruff.read_bytes()).hexdigest());(dest/'invocation.json').write_text(json.dumps(record,indent=2)+'\n');results.append(record)
(out/'summary.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({'cases':len(results),'exact':sum(row['exact'] for row in results),'mismatches':[row for row in results if not row['exact']]}))
