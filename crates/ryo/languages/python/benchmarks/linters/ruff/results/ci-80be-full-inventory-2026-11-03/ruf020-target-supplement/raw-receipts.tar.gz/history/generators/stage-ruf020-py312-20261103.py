from pathlib import Path
import sys,shutil,json,tomllib
r=Path('/tmp/pyi020-ruf020-source-20261103/crates/ryo/languages/python/benchmarks/linters/ruff');sys.path.insert(0,str(r))
from authoring import profile_sources as s,profile_config as c,reference_discrepancies as d
source=Path('/tmp/pyi020-ruf020-source-stage-v2-20261103/profiles/RUF020/repro');dest=Path('/tmp/pyi020-ruf020-countertarget-stage-v2-20261103/RUF020-py312');shutil.copytree(source,dest)
p=tomllib.loads((dest/'benchmark.toml').read_text());s.write_staged_profile(dest/'benchmark.toml',dest/'benchmark.toml',p['query-modules'],'python-target=3.12',{'RUF020':'accepted-syntax'},module_root=dest)
path=dest/'rules/RUF020/cases.toml';cases=tomllib.loads(path.read_text())['cases'];chunks=[]
for case in cases:
 case['expected']=[f for f in case['expected'] if f.get('rule')!='invalid-syntax']
 if 'reference-discrepancy' in case:
  cert=case['reference-discrepancy'];cert['expected']=[f for f in cert['expected'] if f['rule']!='invalid-syntax'];ident=cert['identity'];ident['profile-sha256']=c.sha256(dest/'benchmark.toml');ident['reference-output-sha256']=d.discrepancy_json_hash(d.discrepancy_output(list(case['files']),cert['expected']));ident['intended-output-sha256']=d.discrepancy_json_hash(d.discrepancy_output(list(case['files']),case['expected']));ident['settings-sha256']=d.discrepancy_json_hash({'arguments':['check','--isolated','--output-format','json','--cache-dir','$STATE/ruff','--select','RUF020','--target-version','py312','--',*sorted(case['files'])],'environment':{'RAYON_NUM_THREADS':'1'},'directory':'$ROOT','parser_configuration':'python-target=3.12','project_context_mode':'Isolated'})
  for e in cert['evidence']:e['target-configuration']='python-target=3.12';e['version-rationale']='This supported3.12 target uses the same PEP695 type-parameter scopes independently observed on actual3.13.5. Original source bodies remain unchanged; unsupported3.10 header diagnostics are absent at3.12. The canonical3.10 proof retains those findings. Separate3.10 compatible NoReturn alias controls document namespace behavior without claiming original3.10 execution.'
 for key,value in case.items():
  if key=='name':chunks.append('[[cases]]')
  chunks.append(key+' = '+s.toml_value(value))
 chunks.append('')
path.write_text('\n'.join(chunks));s.assert_staged_profile_fixed_point(dest)
for case in cases:d.validate_reference_discrepancy(dest,case,'RUF020')
print(dest)
