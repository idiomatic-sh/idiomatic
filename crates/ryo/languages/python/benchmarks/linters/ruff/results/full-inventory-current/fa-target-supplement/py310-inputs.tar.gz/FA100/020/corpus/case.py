x: list[int]
