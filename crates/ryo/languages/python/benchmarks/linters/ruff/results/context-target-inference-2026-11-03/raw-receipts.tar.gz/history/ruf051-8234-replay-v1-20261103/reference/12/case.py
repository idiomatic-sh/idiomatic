d={}
if key in d in other: del d[key]
