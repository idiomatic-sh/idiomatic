d={}
if -1j in d: del d[-1j]
