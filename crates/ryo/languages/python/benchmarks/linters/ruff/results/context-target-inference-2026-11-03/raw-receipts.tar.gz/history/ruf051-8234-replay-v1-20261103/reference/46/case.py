if flag: d={}
else: d={}
if key in d: del d[key]
