"%##00--++  r" % value
