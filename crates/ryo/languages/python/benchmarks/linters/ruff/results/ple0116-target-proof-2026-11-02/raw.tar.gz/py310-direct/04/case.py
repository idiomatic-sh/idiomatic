while True:
    try:
        pass
    finally:
        try:
            pass
        except Exception:
            pass
        else:
            continue
