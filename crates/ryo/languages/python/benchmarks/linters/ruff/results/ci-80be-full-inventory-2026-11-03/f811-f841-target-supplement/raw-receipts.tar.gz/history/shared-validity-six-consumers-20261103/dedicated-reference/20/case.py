def outer():
 def inner(x=(value:=1)):
  global value
  nonlocal value
