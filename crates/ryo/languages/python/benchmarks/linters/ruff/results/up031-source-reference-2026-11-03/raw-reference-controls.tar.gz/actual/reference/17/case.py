"%(class)s" % {"class":value}
