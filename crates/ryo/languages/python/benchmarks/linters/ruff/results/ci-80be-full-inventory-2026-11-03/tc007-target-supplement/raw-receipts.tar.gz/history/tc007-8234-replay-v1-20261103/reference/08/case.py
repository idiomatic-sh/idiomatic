from typing import TYPE_CHECKING, TypeAlias
if TYPE_CHECKING:
 class Foo: ...
Alias:TypeAlias=list[Foo]
