b'hello'.strip(b'aba')
