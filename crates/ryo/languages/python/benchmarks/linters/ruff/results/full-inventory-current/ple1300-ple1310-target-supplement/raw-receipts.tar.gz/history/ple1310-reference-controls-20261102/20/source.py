text: bytes = b''
text.strip(b'aa')
