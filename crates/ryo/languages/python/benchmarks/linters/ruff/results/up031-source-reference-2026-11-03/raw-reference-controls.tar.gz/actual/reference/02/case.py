"%s" % (value,)
