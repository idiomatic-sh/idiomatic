from typing import TYPE_CHECKING, TypeAlias
class Foo: ...
def outer():
 if TYPE_CHECKING:
  from external import Foo
 Alias:TypeAlias=Foo
