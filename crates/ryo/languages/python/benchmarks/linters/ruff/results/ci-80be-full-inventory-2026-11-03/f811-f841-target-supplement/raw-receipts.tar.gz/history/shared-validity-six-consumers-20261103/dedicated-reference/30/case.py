def outer():
 value=1
 class C:
  value=2
  def f(self):
   global value
   nonlocal value
