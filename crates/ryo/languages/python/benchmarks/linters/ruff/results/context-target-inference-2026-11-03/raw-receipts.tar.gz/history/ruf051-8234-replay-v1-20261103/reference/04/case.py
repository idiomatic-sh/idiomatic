from typing import Dict
def f(d:Dict):
 if key in d: del d[key]
