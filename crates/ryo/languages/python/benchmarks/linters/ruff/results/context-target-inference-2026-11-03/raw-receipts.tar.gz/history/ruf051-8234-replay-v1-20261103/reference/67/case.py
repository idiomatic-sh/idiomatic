from __future__ import annotations
import builtins
def d[dict]()->dict: ...
if key in d: del d[key]
