class C:
    __slots__ = {"z": "doc", **other, "a": "doc"}
