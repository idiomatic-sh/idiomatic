# ruff: noqa: PLE1300
'%q' % 1
