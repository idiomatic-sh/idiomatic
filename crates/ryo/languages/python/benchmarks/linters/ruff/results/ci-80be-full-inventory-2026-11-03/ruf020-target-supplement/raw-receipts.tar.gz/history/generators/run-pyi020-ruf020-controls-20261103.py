from pathlib import Path
import sys,subprocess,json,hashlib,time
out=Path('/tmp/pyi020-ruf020-independent-controls-20261103');ruff=Path('/home/vscode/.local/bin/ruff');py=Path(sys.executable).resolve()
probes=json.loads((out/'python-probes.json').read_text());inputs=json.loads((out/'reference-inputs.json').read_text())
source=Path('/tmp/ruff-0165-src/crates/ruff_linter/resources/test/fixtures/ruff/RUF020.py').read_text();inputs.append({'rule':'RUF020','name':'full-pinned-RUF020','filename':'RUF020.py','source':source});(out/'executed-reference-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
program='''import ast,sys,json,typing
out=[]
for p in json.load(sys.stdin):
 r={'name':p['name']};ns={}
 try:
  compile(p['source'],p['name']+'.py','exec',flags=ast.PyCF_ONLY_AST,dont_inherit=True)
  code=compile(p['source'],p['name']+'.py','exec',dont_inherit=True);exec(code,ns);f=ns['f'];r['annotations']=repr(f.__annotations__);params=f.__type_params__;r['parameters']=[x.__name__ for x in params]
  try:
   hints=typing.get_type_hints(f);v=hints['return'];args=typing.get_args(v);r['return']=repr(v)
   r['bottom_present']=typing.Never in args;r['type_parameter_present']=any(x in args for x in params);r['str_present']=str in args
   if p.get('parameter'):r['passed']=r['type_parameter_present'] and not r['bottom_present']
   elif p.get('bottom'):r['passed']=r['bottom_present']
   elif p.get('resolution_pair'):
    other=typing.get_type_hints(f,localns={'Never':typing.Never})['return'];r['explicit_local_return']=repr(other);r['explicit_local_bottom_present']=typing.Never in typing.get_args(other);r['passed']=r['str_present'] and not r['bottom_present'] and r['explicit_local_bottom_present']
   else:r['passed']=False
  except Exception as e:r['error']=type(e).__name__;r['message']=str(e);r['passed']=r['error']==p.get('error')
 except Exception as e:r['setup_error']=type(e).__name__;r['message']=str(e);r['passed']=False
 out.append(r)
json.dump({'python':sys.version,'results':out},sys.stdout,indent=2)
'''
p=subprocess.run([str(py),'-c',program],input=json.dumps(probes).encode(),capture_output=True);(out/'cpython.json').write_bytes(p.stdout);(out/'cpython.stderr').write_bytes(p.stderr);assert p.returncode==0,p.stderr
results=[]
for i,r in enumerate(inputs):
 folder=out/'reference'/f'{i:02d}';folder.mkdir(parents=True,exist_ok=True);src=folder/r['filename'];src.write_text(r['source'])
 for target in ['py310','py312']:
  args=[str(ruff),'check','--isolated','--target-version',target,'--select',r['rule'],'--output-format','json',str(src)];q=subprocess.run(args,capture_output=True);(folder/(target+'.json')).write_bytes(q.stdout);(folder/(target+'.stderr')).write_bytes(q.stderr);results.append({'rule':r['rule'],'name':r['name'],'target':target,'args':args,'exit':q.returncode,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'diagnostics':json.loads(q.stdout)})
(out/'reference-results.json').write_text(json.dumps(results,indent=2)+'\n');(out/'invocation.json').write_text(json.dumps({'python_path':str(py),'python_sha256':hashlib.sha256(py.read_bytes()).hexdigest(),'ruff_sha256':hashlib.sha256(ruff.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python_program':program,'reference_invocations':len(results)},indent=2)+'\n')
x=json.loads(p.stdout);print('CPython',sum(z['passed'] for z in x['results']),'/',len(probes));print(json.dumps(x['results'],indent=2))
assert all(z['passed'] for z in x['results'])
