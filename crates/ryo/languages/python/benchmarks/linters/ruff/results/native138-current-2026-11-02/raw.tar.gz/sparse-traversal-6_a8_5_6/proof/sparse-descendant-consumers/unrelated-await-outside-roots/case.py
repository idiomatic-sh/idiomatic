value = outer(deep(leaf(a)), shallow(b))
async def unrelated():
    await work()
