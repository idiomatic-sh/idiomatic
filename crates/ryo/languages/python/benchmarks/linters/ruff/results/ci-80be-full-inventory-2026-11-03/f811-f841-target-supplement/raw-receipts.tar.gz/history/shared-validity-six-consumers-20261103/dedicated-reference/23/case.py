from __future__ import annotations
def f(x:(value:=object)):
 global value
 nonlocal value
