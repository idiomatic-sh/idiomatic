''.strip(chars='aa')
