x = list[int]
