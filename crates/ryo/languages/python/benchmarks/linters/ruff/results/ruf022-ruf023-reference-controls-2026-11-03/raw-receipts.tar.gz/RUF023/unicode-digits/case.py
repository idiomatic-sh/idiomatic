class C:
    __slots__ = ["a٩", "a9"]
