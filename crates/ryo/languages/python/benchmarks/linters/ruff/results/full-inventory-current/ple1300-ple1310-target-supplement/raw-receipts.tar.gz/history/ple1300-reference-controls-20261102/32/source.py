'{:٣d}'.format(1)
