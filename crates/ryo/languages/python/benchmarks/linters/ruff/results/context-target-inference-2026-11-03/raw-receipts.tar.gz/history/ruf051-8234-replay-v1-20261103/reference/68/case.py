import builtins
def outer():
 class C:
  def method(x=(d:=dict())): ...
  if key in d: del d[key]
 dict=custom
