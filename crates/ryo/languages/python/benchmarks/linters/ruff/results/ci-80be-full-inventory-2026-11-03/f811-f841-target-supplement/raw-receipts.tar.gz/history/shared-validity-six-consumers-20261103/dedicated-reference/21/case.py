def outer():
 value=1
 value:int
 def inner():
  global value
  nonlocal value
