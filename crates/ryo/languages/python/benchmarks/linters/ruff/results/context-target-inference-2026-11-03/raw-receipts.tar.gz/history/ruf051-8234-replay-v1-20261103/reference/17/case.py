d={}
if True in d: del d[1]
