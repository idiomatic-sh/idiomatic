if text.startswith(prefix):
    text = text[len(obj=prefix):]
