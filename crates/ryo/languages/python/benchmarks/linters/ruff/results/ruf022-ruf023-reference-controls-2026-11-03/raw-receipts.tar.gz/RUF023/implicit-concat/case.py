class C:
    __slots__ = ["z" "2", "z" "1"]
