def outer():
 value=1
 def f():
  nonlocal value
  global value
