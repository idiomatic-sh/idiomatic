def f():
 global value
 nonlocal value
