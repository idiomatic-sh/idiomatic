"%*s" % (3,value)
