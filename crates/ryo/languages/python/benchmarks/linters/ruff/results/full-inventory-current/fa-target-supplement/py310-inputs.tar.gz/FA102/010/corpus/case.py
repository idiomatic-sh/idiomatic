def f():
    x: int | str
