text: str = ''
text.strip('aa')
