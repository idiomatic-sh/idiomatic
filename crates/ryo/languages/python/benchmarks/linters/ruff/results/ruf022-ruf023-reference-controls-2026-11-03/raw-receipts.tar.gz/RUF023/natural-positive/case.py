class C:
    __slots__ = ["item10", "item2"]
