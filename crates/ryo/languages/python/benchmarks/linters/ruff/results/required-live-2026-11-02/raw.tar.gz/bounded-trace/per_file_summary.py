import collections,datetime,heapq,json,pathlib,time
root=pathlib.Path('/tmp/django-required-live-bounded-trace-20261102')
started=time.perf_counter();active_file=None;active_rule=None;node_counts=collections.Counter();node_cells=collections.Counter();node_executions=collections.Counter();top_repeats=[];file_blocks=[];starts={};top_durations=[];rule_elapsed=collections.defaultdict(lambda:[0.0,0]);unmatched=0

def flush_file():
    if active_file is None:return
    file_blocks.append({'file':active_file,'dag_node_events':sum(node_counts.values()),'unique_nodes':len(node_counts),'max_repeat':max(node_counts.values(),default=0)})
    for node,count in node_counts.items():
        item=(count,active_file,node,node_cells[node],node_executions[node])
        if len(top_repeats)<100:heapq.heappush(top_repeats,item)
        elif item>top_repeats[0]:heapq.heapreplace(top_repeats,item)

def timestamp(value):return datetime.datetime.fromisoformat(value.replace('Z','+00:00'))
for line in (root/'events.jsonl').open():
    x=json.loads(line);f=x.get('fields',{});event=f.get('event')
    if event=='rule_file_start':
        file=f.get('file');rule=f.get('rule')
        if file!=active_file:
            flush_file();active_file=file;node_counts.clear();node_cells.clear();node_executions.clear()
        active_rule=rule;starts[(file,rule)]=timestamp(x['timestamp'])
    elif event=='rule_file_end':
        file=f.get('file');rule=f.get('rule');start=starts.pop((file,rule),None)
        if start is not None:
            duration=(timestamp(x['timestamp'])-start).total_seconds();rule_elapsed[rule][0]+=duration;rule_elapsed[rule][1]+=1
            item=(duration,file,rule)
            if len(top_durations)<100:heapq.heappush(top_durations,item)
            elif item>top_durations[0]:heapq.heapreplace(top_durations,item)
    elif event=='dag_node':
        node=f.get('node');node_counts[node]+=1;node_cells[node]+=f.get('cells',0);node_executions[node]=max(node_executions[node],f.get('executions',0))
flush_file()
result={'schema':'bounded-file-dag-per-file/v1','parse_seconds':time.perf_counter()-started,'file_blocks':len(file_blocks),'top_file_node_repeats':[{'events':count,'file':file,'node':node,'cells_sum':cells,'max_executions_field':maximum} for count,file,node,cells,maximum in sorted(top_repeats,reverse=True)[:30]],'top_rule_file_durations':[{'seconds':sec,'file':file,'rule':rule} for sec,file,rule in sorted(top_durations,reverse=True)[:30]],'top_rules_by_sampled_elapsed':[{'rule':rule,'seconds':value[0],'completed_pairs':value[1]} for rule,value in sorted(rule_elapsed.items(),key=lambda pair:pair[1][0],reverse=True)[:30]],'top_files_by_dag_events':sorted(file_blocks,key=lambda value:value['dag_node_events'],reverse=True)[:20],'unfinished_rule_file_pairs':[{'file':file,'rule':rule,'started':start.isoformat()} for (file,rule),start in starts.items()][:20]}
(root/'per-file-summary.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'parse_seconds':result['parse_seconds'],'file_blocks':result['file_blocks'],'top_repeats':result['top_file_node_repeats'][:5],'top_durations':result['top_rule_file_durations'][:5],'unfinished':result['unfinished_rule_file_pairs'][:2]}))
