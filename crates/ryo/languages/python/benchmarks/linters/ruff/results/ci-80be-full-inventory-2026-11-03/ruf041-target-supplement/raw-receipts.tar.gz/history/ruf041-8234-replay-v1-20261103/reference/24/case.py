from typing import Literal,cast
x=cast(Literal[Literal[1]],value)
