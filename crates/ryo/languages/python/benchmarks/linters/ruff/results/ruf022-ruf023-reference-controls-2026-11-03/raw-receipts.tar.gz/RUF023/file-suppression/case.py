# ruff: noqa: RUF023
class C:
    __slots__ = ["z", "a"]
