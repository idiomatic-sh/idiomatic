class C:
    __slots__ = ["one"]
