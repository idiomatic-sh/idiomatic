'{0:.{width}q}'.format(1,width=3)
