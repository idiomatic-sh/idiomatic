b''.strip(b'ab' b'ca')
