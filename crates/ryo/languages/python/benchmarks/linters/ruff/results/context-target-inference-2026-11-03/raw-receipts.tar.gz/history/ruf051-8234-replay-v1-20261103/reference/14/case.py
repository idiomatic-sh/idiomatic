d={}
if None in d: del d[None]
