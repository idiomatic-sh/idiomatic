from typing import TYPE_CHECKING
TYPE_CHECKING=True
if TYPE_CHECKING:
 from external import Foo
x=Foo
