from __future__ import annotations
Literal=custom
def outer():
 from typing import Literal
 def f()->Literal[Literal[1]]: ...
