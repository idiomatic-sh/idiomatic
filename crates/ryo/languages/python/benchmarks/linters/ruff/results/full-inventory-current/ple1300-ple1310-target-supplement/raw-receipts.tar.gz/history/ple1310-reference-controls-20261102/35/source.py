''.strip('aa')  # noqa: PLE1310
