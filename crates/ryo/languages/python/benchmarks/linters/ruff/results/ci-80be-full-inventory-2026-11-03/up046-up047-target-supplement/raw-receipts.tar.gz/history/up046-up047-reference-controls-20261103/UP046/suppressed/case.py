from typing import Generic, TypeVar, AnyStr
T = TypeVar("T")
class C(Generic[T]): ... # noqa: UP046
