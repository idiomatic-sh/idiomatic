from typing import TYPE_CHECKING
if TYPE_CHECKING:
 from external import Foo
from typing import TypeAlias
Alias:TypeAlias=Foo
