if text.startswith("é😀"):
    text = text[6:]
