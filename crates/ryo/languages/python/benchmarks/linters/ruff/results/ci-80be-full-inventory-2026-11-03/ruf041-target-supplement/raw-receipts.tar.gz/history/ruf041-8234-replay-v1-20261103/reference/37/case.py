from __future__ import annotations
from functools import singledispatch
from typing import Literal
@singledispatch
def fun(x): ...
@fun.register()
def f[Literal](x:Literal[Literal[1]])->Literal[Literal[1]]: ...
