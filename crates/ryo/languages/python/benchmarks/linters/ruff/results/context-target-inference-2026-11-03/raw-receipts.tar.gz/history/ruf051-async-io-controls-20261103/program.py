import sys,json,asyncio,io
results=[]
assert not hasattr(io.StringIO,'__aenter__')
for row in json.load(sys.stdin):
 ns={};exec(compile(row['source'],row['rule']+'.py','exec',dont_inherit=True),ns)
 try:asyncio.run(ns['f']())
 except Exception as e:actual=type(e).__name__
 else:raise AssertionError('standard IOBase unexpectedly entered async context')
 expected='TypeError' if sys.version_info>=(3,11) else 'AttributeError'
 assert actual==expected
 results.append({**row,'expected':expected,'actual':actual,'passed':True,'invocation_model':'Original source unchanged; function f invoked separately using asyncio.run.'})
json.dump({'python':sys.version,'results':results},sys.stdout,indent=2)
