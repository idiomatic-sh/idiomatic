if text.endswith(""):
    text = text[:-len("")]
