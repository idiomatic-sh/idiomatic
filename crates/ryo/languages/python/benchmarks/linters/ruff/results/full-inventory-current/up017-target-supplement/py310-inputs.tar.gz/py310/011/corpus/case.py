import datetime
datetime.timezone.utc  # noqa: F401
