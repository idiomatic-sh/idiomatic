"%(x)s" % {"x":value}
