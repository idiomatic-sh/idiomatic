b''.strip(b'')
