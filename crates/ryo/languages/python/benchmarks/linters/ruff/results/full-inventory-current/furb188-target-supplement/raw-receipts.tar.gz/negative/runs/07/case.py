if text.startswith("a" "é"):
    text = text[2:]
