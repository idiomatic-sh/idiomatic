''.strip()
