from typing import TYPE_CHECKING
if TYPE_CHECKING:
 from external import Foo # noqa: TC004
x=Foo
