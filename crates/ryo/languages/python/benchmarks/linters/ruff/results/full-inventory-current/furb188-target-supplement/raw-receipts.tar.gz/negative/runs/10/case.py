if text.endswith(suffix):
    text = text[:-len(suffix)]
