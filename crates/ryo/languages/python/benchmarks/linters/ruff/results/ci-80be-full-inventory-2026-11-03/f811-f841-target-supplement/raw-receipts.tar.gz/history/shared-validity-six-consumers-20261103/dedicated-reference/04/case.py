def outer():
 from __future__ import annotations
 def inner(x:(value:=object)): pass
def later(x:(other:=object)): pass
