from pathlib import Path
import os,json,hashlib,shutil,subprocess,time,signal,fcntl,datetime,collections
out=Path('/tmp/django-rule-sample12-20261104');out.mkdir(exist_ok=True)
pack=Path('/tmp/ryo-current409-pack-v3-20261103');fields=json.loads((pack/'worker-request-fields.json').read_text());manifest=json.loads((pack/'manifest.json').read_text())
worker=Path('/tmp/axis-nearest-workers-20261104/ruff-worker');build=json.loads((worker.parent/'summary.json').read_text());collector=Path('/tmp/perfile-index-cache-collector-build-20261101/collector/collector-4e1d3d328618bee455f9ee1f6e9c1963f076803e7251bdc953cb55db362d4205')
corpus=Path('/tmp/django-file-program-graph-pair-20261102/graph-on/corpus');frozen=Path('/tmp/django-numeric-sparse-full-20261102');files=json.loads((frozen/'files.json').read_text());assert len(files)==2875
rules=['UP034','RET501','SIM114','RUF028','B021','PLR1708','F401','F821','F841','UP031','B018','UP006']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(worker)==build['workers'][0]['worker_sha256']
identity={'source':build['source_head'],'worker_sha256':sha(worker),'collector_sha256':sha(collector),'parent_pack_sha256':sha(pack/'manifest.json'),'files_sha256':sha(frozen/'files.json'),'corpus_files':2875,'sample_rules':rules,'parent_verified_pack':409,'not_current411_acceptance':True,'cap_seconds':30,'worker_count':1,'uncertified_diagnostic':True,'rule_timings_not_additive_or_subtractable':True,'all53_helper_bindings_retained':len(fields['query_modules'])==53,'unavailable_requested_example':{'rule':'E501','status':'NOT_IN_FROZEN_INVENTORY','replacement':'UP031','not_a_silent_missing_413_slot':True},'supporting_observation_inputs':'All fields of original frozen409 request retained; no observation-input field is present in that original request.'}
(out/'manifest.json').write_text(json.dumps(identity,indent=2)+'\n')
native=lambda s:{'Unix':list(os.fsencode(s))}
def descendants(pid):
 try:children=[int(x)for x in Path(f'/proc/{pid}/task/{pid}/children').read_text().split()]
 except OSError:return []
 return [q for p in children for q in descendants(p)]+children
results=[]
with open('/workspaces/.cargo-build.lock','a')as outer,open('/tmp/ryo-cargo-serial.lock','a')as inner:
 fcntl.flock(outer,fcntl.LOCK_EX);fcntl.flock(inner,fcntl.LOCK_EX)
 # Prepare every request before starting measured children; no canonical suite guard is weakened.
 for rule in rules:
  case=out/rule;case.mkdir(exist_ok=True);profile=case/'profile';(profile/'rules'/rule).mkdir(parents=True,exist_ok=True)
  query=pack/'profile/rules'/rule/'query.ryoql';assert query.is_file(),rule
  shutil.copy2(query,profile/'rules'/rule/'query.ryoql')
  for relative in set(fields['query_modules'].values()):
   src=pack/'profile'/relative;dest=profile/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest);assert sha(src)==sha(dest)
  shutil.copy2(pack/'profile/benchmark.toml',profile/'benchmark.toml')
  request=dict(fields,root=str(corpus),files=files,rules=str(profile/'rules'),source_language='python',cache=str(case/'cache'),rule_applicability={rule:fields['rule_applicability'][rule]})
  (case/'request.json').write_text(json.dumps(request,indent=2)+'\n')
  (case/'selection.json').write_text(json.dumps({'selected_rule':rule,'query_sha256':sha(query),'parent_profile_sha256':sha(pack/'profile/benchmark.toml'),'module_hashes':{name:sha(profile/rel)for name,rel in fields['query_modules'].items()},'request_sha256':sha(case/'request.json'),'canonical_fixed_point_suite_claim':False,'purpose':'Explicit singleton raw diagnostic; permanent shared suite selection transport pending'},indent=2)+'\n')
 print(json.dumps({'event':'sample_started','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),**identity}),flush=True)
 for index,rule in enumerate(rules):
  case=out/rule
  if (case/'result.json').exists():
   saved=json.loads((case/'result.json').read_text());assert saved['request_sha256']==sha(case/'request.json') and saved['worker_sha256']==sha(worker);results.append(saved);continue
  wire={'executable':native(str(worker)),'arguments':[native(x)for x in ['run-ryo','--request-file',str(case/'request.json'),'python-target=3.10']],'environment':[{'name':native(k),'value':native(v)}for k,v in {'RAYON_NUM_THREADS':'1','RYO_FILE_PROGRAM_GRAPH':'0','RYO_FILE_DAG_EXECUTION':'1'}.items()],'directory':native(str(corpus))}
  (case/'collector-request.json').write_text(json.dumps(wire,indent=2)+'\n');begin=time.monotonic();capped=False
  with (case/'observation.json').open('wb')as stdout,(case/'collector.stderr').open('wb')as stderr:
   child=subprocess.Popen([str(collector)],stdin=subprocess.PIPE,stdout=stdout,stderr=stderr,start_new_session=True)
   try:child.communicate(input=json.dumps(wire).encode(),timeout=30)
   except subprocess.TimeoutExpired:
    capped=True
    for pid in descendants(child.pid):
     try:os.kill(pid,signal.SIGTERM)
     except ProcessLookupError:pass
    try:child.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
  result={'rule':rule,'worker_sha256':sha(worker),'request_sha256':sha(case/'request.json'),'status':'FAIL_TIMEOUT'if capped else 'FAIL_OBSERVATION','capped':capped,'collector_exit':child.returncode,'orchestration_wall_seconds':time.monotonic()-begin,'reference_parity_certified':False,'setup_execution_split':'not exposed by this sealed non-instrumented worker; not inferred'}
  try:
   obs=json.loads((case/'observation.json').read_text());assert obs['result']=='Observed';v=obs['output'];raw=bytes(v['stdout']);err=bytes(v['stderr']);(case/'stdout').write_bytes(raw);(case/'stderr').write_bytes(err)
   sec=lambda d:d['secs']+d['nanos']/1e9
   result.update(wall_seconds=sec(v['wall']),cpu_seconds=sec(v['cpu']),peak_rss_bytes=v['rss'],worker_exit=v['status'])
   if not capped and v['status']==0:
    report=json.loads(raw);(case/'report.json').write_text(json.dumps(report,indent=2)+'\n');cov=report['coverage'];complete=report['execution_metadata']['availability']=='complete' and cov['selected']==2875 and cov['evaluated']+cov['skipped']==2875 and cov['unknown_or_unread']==0 and sorted(report['files'])==sorted(files)
    result.update(status='COMPLETED_UNCERTIFIED'if complete else 'FAIL_INCOMPLETE',coverage=cov,diagnostics=len(report['diagnostics']),diagnostic_rule_histogram=dict(collections.Counter(d['rule']for d in report['diagnostics'])),complete_report=complete)
   elif not capped:result['status']='FAIL_WORKER'
  except Exception as error:result['observation_error']=str(error)
  (case/'result.json').write_text(json.dumps(result,indent=2)+'\n');results.append(result)
  summary={**identity,'results':results,'completed_samples':len(results),'ranking_completed_only':sorted([r for r in results if r['status']=='COMPLETED_UNCERTIFIED'],key=lambda r:r['wall_seconds'],reverse=True),'timeouts_are_censored_FAIL_not_timing':True}
  (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'event':'rule_terminal','sample':index+1,**result}),flush=True)
  if index==4:print(json.dumps({'event':'first5_terminal','receipt':str(out/'summary.json')}),flush=True)
 print(json.dumps({'event':'sample12_terminal','receipt':str(out/'summary.json')}),flush=True)
